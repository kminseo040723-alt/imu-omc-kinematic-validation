# Midterm Tasks 1–5 실행 패키지

실제 IMU와 Vicon 파일로 Task 1–5(a), 5(b)를 실행했습니다. results에 계산 결과가 들어 있습니다. 다음 단계는 '다시 계산'이 아니라 수치·그래프·가정 검토와 보고서 작성입니다.

## 다시 실행

Python 3.9 이상에서 ZIP을 풀고 해당 폴더의 터미널에서:

```bash
python -m pip install -r requirements.txt
python run_all.py
```

Task 1 결과를 유지하고 2–5만 재실행:

```bash
python code/run_tasks_2_to_5.py
```

원본은 data/imu.csv와 data/omc_vicon.csv입니다. 원본의 이름만 바꿨으며 내용은 유지했습니다. 결과 폴더는 재실행 시 갱신됩니다.

## 먼저 읽을 파일

- RESULTS_KO.md: 실제 계산 수치, 보고서에 넣을 해석과 확인 사항.
- results/summary_tasks2_5.json: 전체 설정·수치·한계.
- results/task1/summary.json: Task 1 진단 및 인공 결측 검증.
- results/task3/time_alignment.png: 시간 정렬 전후.
- results/task4/orientation_error.png: 전체 자세 오차.
- results/task5/trajectory_*.png: 지정된 BPF 세 가지의 전체 궤적 비교.
- results/task5/period_selection.png: 주기 추정 근거.
- results/task5/period_comparison.png: 같은 구간의 고정 BPF와 주기 기반 BPF 비교.

## 각 Task의 방법과 범위

### Task 1

이전에 만든 코드를 포함했습니다. 입력 Export에 결측이 없어 기본 refined 좌표는 원본과 같습니다. Geometry Flag는 오류 확정이 아닙니다. 인공 결측 실험은 실제 측정 결측과 분리되어 있습니다. 자세한 내용은 README_TASK1_KO.md를 보세요.

### Task 2 — 좌표·부착 관계

Vicon Marker 좌표에 시간 Median 5 Sample, Gaussian sigma=3 Sample(100 Hz에서 0.03 s)를 적용한 후 Empirical template과 Kabsch fitting으로 각 Frame의 자세를 구했습니다. 이는 미분을 위한 추가 처리이며 Task 1 원본을 덮어쓰지 않습니다. smoothing이 tracking 오류를 모두 수정했다는 의미는 아닙니다.

R_OL_to_OG는 열벡터 기준 Marker cluster local -> Vicon global의 proper rotation입니다. Cluster local 축은 Task 1의 선택 Frame에서 정의한 임시 축으로, 안내문의 Marker 번호/축과 동일하다고 가정하지 않았습니다. 각 시각의 rigid-fit residual도 CSV에 저장됩니다.

C = [[1,0,0],[0,0,1],[0,1,0]]는 EUN에서 ENU로 signed channel 순서를 바꾸는 행렬입니다(det=-1). 5–120 s의 OMC Angular velocity와 동기화한 Gyroscope로 고정 mounting rotation Q 및 Gyro bias를 추정했습니다. M=Q C, det(Q)=+1입니다. 이후 gyro_cluster = M (gyro_raw - bias), specific_force_cluster = M acc_raw입니다. IMU acceleration의 단위는 g×9.8로 m/s²로 바꿉니다.

주의: Gyroscope는 회전 부호 규약이 별도로 필요합니다. 이 코드는 원시 Gyroscope 채널이 이 signed map을 따라 OMC의 오른손 Angular velocity와 일치한다는 데이터 기반 보정을 사용합니다. 반사를 포함한 일반 좌표변환에서 polar vector/axial vector가 항상 같은 법칙을 따른다고 가정한 것이 아닙니다. 가속도는 OMC 자세로 Global에 옮겼을 때 평균이 약 +g Z가 되는지 추가 점검했습니다. 하드웨어 Firmware의 축 정의는 별도 확인 대상입니다.

Fixed global-frame alignment는 OMC 기반 초기 자세 안에 포함합니다. 독립적인 IMU heading/global reference가 없어 두 독립 Calibration을 따로 식별했다고 주장하지 않습니다. Magnetometer는 이번 gyro-only 자세 추정에 사용하지 않습니다.

Task 2에서 필요한 시간 대응은 Task 3 추정값을 이용합니다. 따라서 실행 내부에서는 OMC 자세 계산 -> 시간 추정 -> 부착 관계 추정 순서입니다. 보고서 Task 순서는 안내문대로 유지할 수 있습니다.

### Task 3 — 시간 정렬

imu_relative_time=imu_time-first_imu_time, OMC time=(Frame-first_Frame)/100.
구간별 Angular-speed magnitude의 상관으로 시간 차이 변화를 확인하고 다음 관계를 추정했습니다.

t_OMC = alpha × imu_relative_time + beta

beta가 음수이면 IMU 상대시각 0이 OMC Export 시작보다 앞에 위치합니다. alpha는 기록 시간축의 비율입니다. 단일 Offset만으로 충분하지 않아 affine mapping을 사용했으며 하드웨어 clock 자체의 원인을 확정한 것은 아닙니다. 전체 기록으로 clocks를 맞추고 겹치는 구간만 100 Hz로 Linear resampling합니다. Extrapolation은 하지 않습니다.

### Task 4 — Quaternion

Quaternion 저장 순서: x,y,z,w. Active rotation: cluster local -> OMC global.
첫 공통 시각의 OMC 자세로 초기화합니다. 이후 보정한 Body-frame Gyroscope를 인접 Sample 평균으로 적분하며 q_next = q_current ⊗ delta_q입니다. 계산시간은 정렬된 OMC 시간축의 dt입니다. 중간에 OMC 자세로 반복 교정하지 않습니다. Quaternion sign continuity를 맞추고 relative rotation angle로 평가합니다.

Gyro Calibration은 5–120 s에 OMC를 이용했습니다. Angular velocity validation RMSE는 120 s 이후입니다. 따라서 완전히 독립적인 IMU 추정으로 소개하면 안 됩니다.

### Task 5(a) — 궤적

위 IMU 자세로 acceleration을 Global frame으로 옮기고 [0,0,9.8] m/s²를 빼 Linear acceleration을 만듭니다. 4차 Butterworth prototype BPF를 SOS forward/backward filtering으로 적용합니다. Bandpass 변환과 forward/backward 적용 때문에 최종 필터 응답의 차수는 prototype의 4와 동일하지 않습니다. 지정 band는 0.3–5 / 0.5–7 / 1.1–10 Hz입니다.

Filtered acceleration -> Trapezoidal integration -> Velocity -> Trapezoidal integration -> Position. 공통 초기 Position은 OMC 비교점 위치, 초기 Velocity는 0으로 가정했습니다. Endpoint fitting, ZUPT, 궤적 Scaling은 적용하지 않았습니다. 초기 실제 속도와 다르면 적분 결과에 영향을 줍니다.

중요: 물리적인 IMU sensing center와 Marker centroid 사이의 위치가 제공되지 않았습니다. 기본 비교점은 네 Marker centroid이며 두 점이 같다는 근사입니다. '같은 Module point 비교'를 완전히 확인하려면 실제 centroid->IMU vector(현재 empirical cluster local 축 기준, mm)가 필요합니다. 확인한 값이 있으면 다음처럼 실행합니다(아래는 인자 형식이며 실제 측정값을 넣으세요).

python code/run_tasks_2_to_5.py --lever-arm-mm dx dy dz

이때 OMC 비교점 = centroid + R_OMC × lever_arm입니다. 가속도 자체는 IMU sensing center의 것으로 사용합니다.

### Task 5(b) — 주기 기반 BPF

OMC centroid Z에서 30 s Window별 주기성을 검사하여 후보를 고릅니다. RMSE를 최소화하도록 구간을 고르지 않았습니다. 같은 발 높이의 연속 Peak 사이를 Full cycle로 정의하고, PSD peak 주변의 합리적인 간격들의 중앙값으로 T를 계산합니다. 한 발의 Full cycle이며 양발 step frequency와 구분합니다.

선택 BPF: lower=0.3 f0, upper=min(max(3 f0,3 Hz),10 Hz), f0=1/T. 이는 기본 주파수를 남기고 일부 고조파를 통과시키려는 한 가지 초기 설계이며 최적 필터라는 주장은 아닙니다. 실제 선택된 3 Hz는 약 4.7 f0에 해당합니다.

5(a)와 동일한 전체 기록, 자세, 초기조건, 필터 적용 단계, 적분법을 유지해 각 Filter의 궤적을 계산한 뒤 동일한 주기 구간만 잘라 비교합니다. 구간 시작에서 적분을 다시 0으로 초기화하지 않습니다. 이 때문에 해당 구간까지 누적된 오차도 비교에 포함됩니다.

실험 당시 지시된 박자 정보는 제공되지 않았으므로, 자동으로 선택한 구간이 지시된 주기 운동 구간인지 확인해야 합니다. 박자 한 번과 Full cycle의 관계도 현재 파일만으로 확정할 수 없습니다. 구간을 확인한 경우:

python code/run_tasks_2_to_5.py --period-start 120 --period-end 150

숫자는 실제 확인한 시간 구간으로 바꿀 수 있습니다.

## CSV 열

벡터 뒤 _0/_1/_2는 X/Y/Z입니다. quaternion_xyzw_0...3은 x/y/z/w입니다. time_s는 OMC Export 상대시간(단 Task 2 imu_aligned.csv는 변환 전 IMU 상대시간)입니다. mm와 m/s², rad/s 등은 열 이름에 적었습니다.

## 해석 시 주의

보고서에 결과가 잘 맞는다고 쓰기 전에 그래프와 실제 RMSE를 확인하세요. 큰 오차도 실제 결과로 남겼습니다. 자세 Drift, Gravity leakage, 제거된 저주파 실제 움직임, 초기속도 가정, 미확인 비교점, OMC 품질이 영향을 줄 수 있습니다. 어느 하나를 원인으로 확정하려면 추가 분리 검증이 필요합니다. 데이터와 코드만으로 확정할 수 없는 항목은 RESULTS_KO.md에 표시했습니다.
