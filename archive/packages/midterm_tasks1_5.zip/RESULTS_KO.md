# Task 1–5 실행 결과

모든 Task의 계산 및 출력 파일 생성 완료. 아래 수치는 현재 가정과 구현에 따른 결과이며, 같은 물리적 비교점과 지시된 운동 박자는 추가 확인이 필요합니다.

## 시간 및 좌표 정렬
- t_OMC = 1.004217231 × (imu_time − 1626.452517) -2.473745 s
- 시간축 보정 후 Angular-speed correlation: 0.9715
- 5–120 s OMC 데이터로 고정 축/부착 관계 및 Gyro bias를 보정했습니다.

## Task 4
- Relative rotation error 평균: 20.94°
- 마지막: 46.43°; 최대: 55.26°

## Task 5(a)

| BPF | Position RMSE (mm) | Final error (mm) |
|---|---:|---:|
| 0.3_5Hz | 1960.11 | 1480.37 |
| 0.5_7Hz | 1890.59 | 1405.28 |
| 1.1_10Hz | 2293.71 | 435.88 |

## Task 5(b)
- 자동 선택 구간: 120.00–149.99 s
- 같은 발 Full cycle T=1.565 s; f0=0.639 Hz
- 선택 BPF: 0.192–3 Hz

| 방법 | 같은 구간 Position RMSE (mm) |
|---|---:|
| fixed_0.3_5 | 1967.46 |
| period_informed | 2334.89 |

전체 기록에서 Filter와 적분을 동일하게 수행하고 같은 구간을 추출했습니다. 주기 기반 band는 운동 주파수에서 정했으며 OMC 궤적 RMSE에 맞춰 최적화하지 않았습니다. 이번 결과에서 개선 여부는 위 수치로 판단합니다.

## 제출 전 확인할 두 항목
1. IMU sensing center와 Marker centroid 사이의 실제 위치 관계. 현재는 일치한다고 가정했습니다.
2. 120–150 s가 실험에서 지시한 주기 운동 구간인지, 박자 한 번이 Full cycle에서 어떤 의미였는지. 현재는 높이 신호에서 자동으로 찾았습니다.

## 실행 확인
Quaternion norm, proper mounting rotation, 시간 외삽 없음, 수치 출력 finite, 5(a)/5(b)의 고정 BPF 결과 동일성을 검사했습니다. 검증 결과는 results/validation_checks.json에 있습니다.