from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(root/'code/task1_marker_refinement.py'),'--input',str(root/'data/omc_vicon.csv'),'--out',str(root/'results/task1'),'--demo'],check=True)
subprocess.run([sys.executable,str(root/'code/run_tasks_2_to_5.py')],check=True)
print('Completed:',root/'results')
