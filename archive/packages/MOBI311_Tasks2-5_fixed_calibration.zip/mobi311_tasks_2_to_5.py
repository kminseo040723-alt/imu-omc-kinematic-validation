"""Task 2--5 entry point. Existing Task 1 is not rerun.

Run from this directory with: python mobi311_tasks_2_to_5.py
"""

from mobi311_tasks_1_to_5 import main


if __name__ == '__main__':
    main()
