# Validation of IMU-based Kinematic Estimation

**Name / Student ID:** [Insert] / [Insert]  
**Report sections:** Tasks 2–5 (to be combined with the student's already completed Task 1)

## 2. Methods

### 2.2. IMU-to-OMC coordinate alignment

Four markers were attached around the Arduino Nano 33 IMU near the front of the ankle. The recorded OMC positions are expressed in the right-handed global East–North–Up frame (OG), whereas the assignment specifies a left-handed local East–Up–North (EUN) frame for the IMU. We used the completed, fully observed OMC marker coordinates as the fixed geometry reference; **Task 1 reconstruction was not rerun or modified**. The local OMC marker-cluster frame (OL) was defined by the empirical initial marker layout, rather than assuming that markers in the supplied image were numbered identically to those in the slides. In the first 200 OMC frames, local +X was chosen from marker 1 toward marker 2, local +Y from the orthogonalized marker-2-to-marker-3 direction, and +Z from their right-handed cross product. The marker centroid is the OL origin.

For column vectors, the axis-order conversion from the recorded EUN to right-handed ENU components is

\[
C=\begin{bmatrix}1&0&0\\0&0&1\\0&1&0\end{bmatrix},\qquad\det C=-1.\tag{1}
\]

This is an improper handedness transformation, **not a physical rotation**. The additional constant mounting rotation \(Q\), satisfying \(\det Q=+1\), maps converted IMU components to OL. Its value was estimated independently of time synchronization using two directional constraints: (i) the mean specific-force direction measured during the initial 1–5 s IMU stationary period, and (ii) the approximate board-axis direction visible in the ankle photograph. The latter was assumed to mean that converted IMU +X is approximately OL +X, but the positive electrical axes and physical marker numbering remain unverified.

\[
Q=\arg\min_{R\in SO(3)}\big[100\lVert R\hat{\mathbf g}_{\mathrm{IMU}}-\hat{\mathbf g}_{\mathrm{OL}}\rVert^2+\lVert R\mathbf e_x-\mathbf e_x\rVert^2\big],\quad M=QC.\tag{2}
\]

Here \(\hat{\mathbf g}_{\mathrm{IMU}}\) is the normalized static acceleration after the EUN-to-ENU component exchange, and \(\hat{\mathbf g}_{\mathrm{OL}}\) is the global-up vector resolved by the initial OMC marker pose in OL. The 100:1 weighting reflects a stronger measured-gravity constraint and a weaker visual board-axis estimate. The static gyro mean provided the constant raw gyro bias \(\mathbf b_g\). The fixed transformations were

\[
\boldsymbol\omega_{\mathrm{OL}}=M\big(\tfrac\pi{180}\boldsymbol\omega_{\mathrm{raw}}-\mathbf b_g\big),\qquad
\mathbf f_{\mathrm{OL}}=M\big(9.8\mathbf a_{\mathrm{raw}}\big).\tag{3}
\]

The raw IMU angular velocity is in deg/s and acceleration in g; the aligned outputs are rad/s and m/s². Because angular velocity is mathematically an axial vector, a literal left-handed-to-right-handed conversion can introduce an additional parity sign. We did **not** assume that the Arduino firmware follows that ideal mathematical convention: applying the same *recorded channel* sign mapping to both modalities was a declared operational assumption, tested **after** Task 3. Rotation matrices were used for this fixed calibration; quaternions were used for the time-varying attitude in Task 4. A single static gravity direction cannot establish the rotation about the vertical axis without another reference [1].

### 2.3. OMC and IMU time synchronization

The empirical four-marker reference was fitted to each OMC frame by proper SVD/Kabsch rigid-body least squares [2]. To reduce differentiation noise, OMC positions were median-filtered over five samples and Gaussian-smoothed (\(\sigma=3\) OMC samples), without altering the Task 1 data. The fitted successive orientations yielded local angular velocity

\[
\boldsymbol\omega_{\mathrm{OMC},k}=\frac{\operatorname{Log}(R_k^TR_{k+1})^\vee}{t_{k+1}-t_k}.\tag{4}
\]

We compared **angular-speed magnitudes** to synchronize the two recordings. Local correlations in five 120-s windows first estimated approximate lags, and correlation maximization refined the affine clock relation

\[
t_{\mathrm{OMC}}=\alpha(t_{\mathrm{IMU}}-t_{\mathrm{IMU},0})+\beta.\tag{5}
\]

The negative-\(\beta\) convention means that the first recorded IMU timestamp maps to a time before the first OMC-exported frame. IMU channels were linearly interpolated onto the measured OMC 100-Hz time grid within the overlapping interval, without extrapolation. Critically, the OMC angular velocities were **not used to estimate or modify the Task 2 mounting rotation**.

### 2.4. Rotational kinematic estimation

The quaternion represents the active OL-to-OG rotation, stored as \([q_x,q_y,q_z,q_w]\), scalar last. Its initial value was the first synchronized OMC pose, applied only once. For body-frame IMU angular velocity, it was integrated with a right-multiplied midpoint rotation increment:

\[
q_{k+1}=q_k\otimes\operatorname{quat}\big(\tfrac12(\boldsymbol\omega_k+\boldsymbol\omega_{k+1})\Delta t_k\big).\tag{6}
\]

The OMC rigid-body orientation provided a reference at each synchronized sample; the angular error was the principal angle of \(R_{\mathrm{OMC}}^TR_{\mathrm{IMU}}\). No OMC updates or magnetometer correction were injected during gyro integration.

### 2.5. Linear kinematic estimation and period-based filtering

Gyro-integrated attitude transforms the aligned accelerometer **specific force** from OL to OG. Gravity is removed only after this transformation:

\[
\mathbf a_{\mathrm{OG}}=R_{\mathrm{OG}\leftarrow\mathrm{OL}}^{\mathrm{IMU}}\mathbf f_{\mathrm{OL}}-[0,0,9.8]^T\;\mathrm{m/s^2}.\tag{7}
\]

For Task 5(a), each assigned Butterworth band-pass setting (0.3–5, 0.5–7, and 1.1–10 Hz) was applied to global gravity-compensated acceleration using a fourth-order filter with forward-backward second-order-section filtering. Velocity and position were calculated by cumulative trapezoidal integration, initialized at zero velocity and the first OMC marker-centroid position. The same OMC centroid was used as the position reference; the unknown IMU-to-marker-centroid lever arm was **assumed zero for this comparison**. The three-dimensional position RMSE is

\[
\mathrm{RMSE}=\sqrt{N^{-1}\sum_{k=1}^N\lVert\mathbf p_{\mathrm{IMU},k}-\mathbf p_{\mathrm{OMC},k}\rVert^2}.\tag{8}
\]

For Task 5(b), a 30-s segment with periodic same-foot marker-centroid height was selected from OMC alone. Repeated peaks of the *same instrumented foot* define a full foot-motion cycle, \(T\), and \(f_0=1/T\). Lower and upper cutoffs were chosen as \(0.3f_0\) and \(\max(3f_0,3\,\mathrm{Hz})\) (upper cap 10 Hz). Only the filter band changed: full-record filtering/integration was run for both methods, then their trajectories were compared over the same periodic segment. No independent record of the instructed rhythm was available, so its mapping to the selected cycle remains unverified.

## 3. Results

### 3.2. Fixed calibration

The EUN-to-OL operational matrix was

\[
M=\begin{bmatrix}
0.97292&0.23047&0.01744\\
-0.23009&0.97293&-0.02157\\
0.02194&-0.01697&-0.99962
\end{bmatrix},\qquad \det(M)=-1.\tag{9}
\]

The corresponding **proper** mounting rotation for *already converted* ENU components was

\[
Q=\begin{bmatrix}
0.97292&0.01744&0.23047\\
-0.23009&-0.02157&0.97293\\
0.02194&-0.99962&-0.01697
\end{bmatrix},\qquad \det(Q)=+1.\tag{10}
\]

The raw gyro bias was \((+0.21592,+0.02299,-0.81486)\) deg/s, estimated from raw IMU 1–5 s. The dominant signed mapping was therefore approximately \((+X,+Y,-Z)\), with nonzero X–Y mixing due to mounting. The static gravity angular residual after fitting was 0.132° **in-sample**, which alone does not verify heading or hardware signs.

### 3.3. Time synchronization and post-hoc axis verification

The affine clock estimate was \(\alpha=1.00421650\), \(\beta=-2.473879\) s, with angular-speed magnitude correlation \(r=0.971786\). Fig. 1 compares a representative interval before and after synchronization.

![Fig. 1. Angular-speed magnitude before and after synchronization.](mobi311_results_task2to5/task3/synchronization.png)

*Fig. 1. OMC and IMU angular speed (rad/s), 280–291 s.*

As a **subsequent validation**, the Task 2 aligned angular velocity was compared to OMC over 120–600 s: vector RMSE **22.19 deg/s**, median directional disagreement **7.17°** for angular speeds above 0.5 rad/s. The OMC angular-velocity RMS was 102.29 deg/s. An all-channel sign reversal produced RMSE **206.41 deg/s**. This supports the chosen *recorded channel signs*, while the exact PCB/firmware convention has not been independently verified. OMC-derived angular velocities were never used to refit the Task 2 transformation.

### 3.4. Quaternion orientation

The average orientation error was **3.41° during the first 30 s**, rising to **89.95° across the full record**, with **165.12° final error**. Fig. 2 presents the accumulated error.

![Fig. 2. Relative orientation error over time.](mobi311_results_task2to5/task4/orientation_error.png)

*Fig. 2. Relative IMU–OMC rotation error in degrees.*

### 3.5. Fixed-band IMU trajectory

**Table 1. Task 5(a) position errors for the whole recording (mm).**

| Filter cutoff (Hz) | 3-D position RMSE (mm) | Final position error (mm) |
|---|---:|---:|
| 0.3–5 | 2238.50 | 1022.43 |
| 0.5–7 | **2016.65** | 1197.94 |
| 1.1–10 | 2309.55 | **473.01** |

![Fig. 3. 0.3–5 Hz trajectory.](mobi311_results_task2to5/task5/trajectory_0.3_5Hz.png)

*Fig. 3. OMC centroid and IMU-estimated XYZ positions under 0.3–5 Hz filtering (mm).*

![Fig. 4. 0.5–7 Hz trajectory.](mobi311_results_task2to5/task5/trajectory_0.5_7Hz.png)

*Fig. 4. OMC centroid and IMU-estimated XYZ positions under 0.5–7 Hz filtering (mm).*

![Fig. 5. 1.1–10 Hz trajectory.](mobi311_results_task2to5/task5/trajectory_1.1_10Hz.png)

*Fig. 5. OMC centroid and IMU-estimated XYZ positions under 1.1–10 Hz filtering (mm).*

### 3.6. Period-informed trajectory

The automatically selected periodic interval was **120–150 s**. The same-foot cycle was \(T=1.565\) s, implying \(f_0=0.63898\) Hz; the informed passband was **0.192–3.000 Hz**.

![Fig. 6. OMC height periodicity and spectrum.](mobi311_results_task2to5/task5/period_selection.png)

*Fig. 6. Period selection from OMC centroid height and corresponding frequency spectrum.*

**Table 2. Task 5(b) position RMSE on the same 120–150-s segment.**

| Band-pass filter (Hz) | Segment vector RMSE (mm) |
|---|---:|
| Fixed 0.3–5 | 2130.35 |
| Period-informed 0.192–3 | **2045.86** |

![Fig. 7. Period comparison on same 30 seconds.](mobi311_results_task2to5/task5/period_comparison.png)

*Fig. 7. OMC and both IMU trajectories on the identical 120–150-s interval (mm).*

## 4. Discussion

**Task 4.** The first 30 s showed reasonable orientation agreement, but the full-run error became severe. The initial OMC pose only fixed the starting quaternion; gyro bias, scale uncertainty, residual mounting error, and noise accumulated thereafter. No online reference corrected yaw drift. The validation therefore supports short-interval orientation changes more strongly than long-term absolute orientation.

**Task 5(a).** The 0.5–7 Hz condition had the lowest whole-record trajectory RMSE, but all filters produced meter-level differences. Increasing the lower cutoff can reduce low-frequency drift while also discarding genuine slow body translation and part of the walking fundamental. Increasing the upper cutoff retains faster foot impacts and more sensor noise. The severe long-term orientation drift also mixes gravity into horizontal acceleration; this small error is then integrated twice into substantial position error. Unknown centroid-to-IMU separation and the assumed initial velocity further limit comparison of exactly the same point.

**Task 5(b).** The selected band retained the roughly 0.639-Hz same-foot periodic component and several harmonics. Its 30-s position RMSE improved by approximately 84.50 mm (4.0%) relative to the selected fixed-band baseline but remained over 2 m. The comparison therefore indicates limited relative benefit, not an accurate reconstruction of absolute translation. Both trajectories inherited position offsets accumulated before the segment. Without the actual instructed cadence and exact lever arm, the interpretation is preliminary.

**Overall limitation.** The wearing photograph is evidence of mounting location and approximate orientation, not an unambiguous sensor-axis reference. Static gravity resolves tilt but not the remaining rotation about gravity. The Task 2 calibration is explicitly a conditional, synchronization-independent candidate, with recorded-channel consistency evaluated only after Task 3. A board-axis drawing with known positive labels or an independent deliberate axis-rotation trial would strengthen physical calibration [3].

## References

[1] Silva, F. O., Paiva, L. P. S., and Carvalho, G. S. “Error Analysis of Accelerometer- and Magnetometer-Based Stationary Alignment.” *Sensors* 21(6), 2040, 2021. https://doi.org/10.3390/s21062040

[2] Kabsch, W. “A solution for the best rotation to relate two sets of vectors.” *Acta Crystallographica Section A* 32(5), 922–923, 1976. https://doi.org/10.1107/S0567739476001873

[3] Lee, J. K., and Jung, W. C. “Quaternion-Based Local Frame Alignment between an Inertial Measurement Unit and a Motion Capture System.” *Sensors* 18(11), 4003, 2018. https://doi.org/10.3390/s18114003

## Reproducibility

With the full unpacked folder available, run `python mobi311_tasks_2_to_5.py`; output is written to `mobi311_results_task2to5/`. **Task 1 is not executed or overwritten.** The code uses the provided complete Vicon ASCII export to define the marker-cluster local axes. If a separate manually refined Task 1 CSV must replace the export, its marker labels, time convention and units should be confirmed before substitution. This text is a section draft for insertion into the assignment's consolidated Task 1–5 report, not the final submission PDF.
