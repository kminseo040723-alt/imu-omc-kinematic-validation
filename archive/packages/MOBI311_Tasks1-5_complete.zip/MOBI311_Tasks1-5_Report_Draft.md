# Validation of IMU-based Kinematic Estimation

**Name / Student number:** [Insert name] / [Insert student number]  
**Module:** Foot-mounted Arduino Nano 33 IMU with a four-marker optical plate  
**Report status:** Reproducible analysis draft; verify marker numbering and actual board-axis polarity before submission.

## Abstract

This study aligned and validated the kinematics of a foot-mounted inertial measurement unit (IMU) against four optical motion capture (OMC) markers during approximately 10 minutes of movement. The Vicon export contained 60,806 frames at 100 Hz and no missing marker coordinates; therefore, the marker-reconstruction algorithm was evaluated using explicitly simulated missing intervals. The IMU contained 58,488 samples. A physically motivated, time-synchronization-independent fixed calibration was obtained from a stationary accelerometer measurement, an empirical OMC marker reference, and a documented approximate board-axis direction inferred from the wearing photograph. The left-handed EUN to right-handed ENU permutation was distinguished from the subsequent proper mounting rotation. Only after fixed calibration, OMC and IMU angular-speed magnitudes were synchronized by an affine clock transform; their correlation was 0.972. Post-synchronization, the independent fixed calibration produced an angular-velocity vector RMSE of 22.19 deg/s over the later validation period. Quaternion gyro integration gave an initial-30-s average orientation error of 3.41 degrees but accumulated substantial drift during the full record. For fixed band-pass settings of 0.3–5, 0.5–7, and 1.1–10 Hz, three-dimensional position RMSEs were 2.24, 2.02, and 2.31 m, respectively. An OMC-derived same-foot cycle of 1.565 s informed a 0.192–3 Hz filter, which modestly reduced the position RMSE on the selected segment relative to the 0.3–5 Hz baseline. Results show both the value and limitations of the sequential IMU-to-OMC processing chain.

## 1. Introduction

Low-cost wearable IMUs estimate motion from angular velocity and specific force, whereas OMC measures marker positions directly. Sensor-axis differences, independent clocks, measurement noise, and integrated gyro/accelerometer bias prevent direct comparisons. A fixed local-frame calibration is necessary even before time matching; stationary gravity establishes two tilt degrees of freedom but cannot uniquely resolve heading without another reference [2]. Related studies use motion-based local-frame alignment to resolve an IMU-to-OMC relationship [3]. This experiment instead uses static gravity plus an explicitly documented visual axis cue for Task 2 so that its calibration does not depend on Task 3. The workflow proceeds sequentially through marker refinement, spatial alignment, clock alignment, quaternion orientation estimation, and acceleration-derived trajectory estimation.

## 2. Methods

### 2.1 Dataset and reference frames

The measured plate was attached approximately vertically to the lower leg/foot near the ankle, with the IMU mounted near its center. The image establishes placement but does **not** establish the positive electronics axes, marker identities, or firmware gyro sign conventions. Vicon positions are represented as column vectors in the right-handed OMC global East–North–Up frame (OG), in millimeters. Raw IMU channels are labeled left-handed local East–Up–North (IL), with accelerations in g and angular velocities in deg/s. In this study OL denotes an independently defined, right-handed OMC marker-plate local coordinate system. We never assume that the numerical marker labels are physically interchangeable with the illustrative schematic in the assignment slides.

For four markers, the first 200 OMC frames were averaged. The vector from empirical marker 1 to marker 2 defined the local positive X axis; an orthogonalized marker-2-to-marker-3 vector defined positive Y; X cross Y defined positive Z. With the initial OL-to-OG rotation \(R_0\), the centered marker template was

\[
\mathbf{s}_j=R_0^T\big(\overline{\mathbf p}_{j}-\overline{\mathbf c}\big),\quad
\overline{\mathbf c}=\tfrac14\sum_{j=1}^{4}\overline{\mathbf p}_j.\tag{1}
\]

All matrices act on **column vectors**. The center of the four-marker plate is used as a proxy for the IMU location in Task 5; their actual displacement was not measured.

### 2.2 Task 1: OMC marker refinement

For frames with at least three noncollinear visible markers, a proper rigid rotation and translation can be estimated by the Kabsch/SVD least-squares fit [1]. The estimated pose reconstructs masked markers using the fixed template. Complete short gaps can be filled by interpolating translations and applying quaternion spherical linear interpolation (SLERP) between the nearest reliable orientations. Two markers do not in general determine a unique three-dimensional orientation without further assumptions; extrapolation over long periods is unreliable.

Inspection of the **actual supplied Vicon export** found zero non-finite marker samples. To demonstrate the algorithm without falsely presenting invented losses as real, marker 1 was masked over 180.00–180.80 s, and all four markers were masked over 185.00–185.35 s in a held-out *synthetic occlusion test*. All Tasks 2–5 use the original unmasked observations. Marker positions were median-filtered over five frames and Gaussian-smoothed with \(\sigma=3\) frames **only for the numerical derivative used in Task 3**, leaving the Task 1 CSV unchanged.

### 2.3 Task 2: IMU-to-OMC coordinate alignment independent of time sync

The channel-order conversion from the provided left-handed EUN ordering to a right-handed ENU component ordering is

\[
C_{\mathrm{EUN}\rightarrow\mathrm{ENU}}
=\begin{bmatrix}1&0&0\\0&0&1\\0&1&0\end{bmatrix},
\qquad\det(C)=-1.\tag{2}
\]

The exchange of Y and Z is a **handedness conversion**, not a proper three-dimensional physical rotation. A distinct rotation \(Q\in SO(3)\), with \(\det(Q)=+1\), maps the converted IMU ENU components to OL. A single static accelerometer measurement gives a body-frame gravity direction; it cannot determine the complete three-dimensional mounting orientation because rotation about the gravity axis remains unobservable [2]. A second, weaker reference was introduced from the mounting photograph: **the positive converted IMU X axis was assumed approximately parallel to the empirically chosen OL positive X axis**. This positive direction is a *hypothesis*, not an externally verified fact.

Let \(\widehat{\mathbf g}_{\mathrm{ENU}}\) denote the unit vector of the stationary raw accelerometer mean (1–5 s) after applying \(C\). Let \(\widehat{\mathbf g}_{\mathrm{OL}}=R_0^T(0,0,1)^T\), representing the same local vertical direction from the initial OMC pose. Estimate the proper fixed mounting rotation via a weighted two-vector Wahba/Kabsch fit:

\[
Q=\arg\min_{R\in SO(3)}\left[100\left\|R\widehat{\mathbf g}_{\mathrm{ENU}}-\widehat{\mathbf g}_{\mathrm{OL}}\right\|^2+\left\|R\mathbf e_x-\mathbf e_x\right\|^2\right].\tag{3}
\]

The gravity-to-visual weighting of 100:1 prioritizes the direct stationary measurement over uncertain visual axis alignment. It is a stated engineering choice. Neither a synchronized time vector nor OMC angular velocity was used to fit \(Q\). The resulting operational channel map is \(M=QC\).

The initial stationary mean raw gyro was used as a constant raw-channel bias \(\mathbf b_g\), and the units were converted as follows:

\[
\begin{split}
\boldsymbol\omega_{\mathrm{OL}}(t)&=M\big[\tfrac\pi{180}\boldsymbol\omega_{\mathrm{raw}}(t)-\mathbf b_g\big],\\
\mathbf f_{\mathrm{OL}}(t)&=M\big[9.8\mathbf a_{\mathrm{raw}}(t)\big].
\end{split}\tag{4}
\]

Important sign qualification: angular velocity is an *axial vector*, so an ideal mathematically left-handed sensor basis may require an extra parity sign under an improper axis conversion. Whether the recorded gyroscope channels already incorporate that sign depends on the Arduino firmware/API convention, which is unavailable. Equation (4) treats the stored gyro and accelerometer channels as sharing the same **operational signed map**; this assumption is explicitly evaluated against synchronized OMC angular velocities **after** Task 3, not silently asserted. Likewise, the approximate photo-derived X sign must be checked against the physical board markings before claiming hardware-verified mounting calibration. Task 2 uses **rotation matrices**; quaternions are reserved for time-varying orientation integration in Task 4.

### 2.4 Task 3: Time synchronization

For every OMC frame, a proper rigid pose \(R_{\mathrm{OG}\leftarrow\mathrm{OL}}(t)\) was obtained by fitting the empirical template to the smoothed marker coordinates. OMC angular velocity was derived from consecutive rotations:

\[
\boldsymbol\omega_{\mathrm{OMC},k}=\frac{1}{t_{k+1}-t_k}
\operatorname{Log}\!\left(R_k^T R_{k+1}\right)^\vee.\tag{5}
\]

Angular-speed **magnitudes** \(\|\boldsymbol\omega_{\mathrm{OMC}}\|\) and \(\|\boldsymbol\omega_{\mathrm{OL}}\|\) were compared. Magnitudes are unchanged by a fixed orthogonal axis map and thus do not require refitting Task 2. Local correlations over 120-s windows with candidate lags from −30 to +30 s gave initial clock offsets. A two-parameter affine model was then refined by maximizing whole-record Pearson correlation:

\[
t_{\mathrm{OMC}}=\alpha\left(t_{\mathrm{IMU}}-t_{\mathrm{IMU,first}}\right)+\beta.\tag{6}
\]

Here a negative \(\beta\) means that the first IMU sample is mapped to an OMC time before the first exported OMC frame. Channels were linearly interpolated onto the observed 100-Hz OMC grid in the overlapping time window only; no endpoint extrapolation was used. This clock model is empirical rather than a separately verified hardware clock-rate diagnosis.

### 2.5 Task 4: Rotational kinematic estimation

OMC orientations were defined by the fitted OL-to-OG rotation matrices. The IMU quaternion represents the *active* OL-to-OG orientation in scalar-last SciPy notation \((q_x,q_y,q_z,q_w)\). Its initial value was taken from the first **synchronized OMC pose once**, as allowed by the assignment. It was then integrated using the midpoint body angular velocity:

\[
q_{k+1}=q_k\otimes\operatorname{quat}\!\left[\tfrac12
(\boldsymbol\omega_{\mathrm{OL},k}+\boldsymbol\omega_{\mathrm{OL},k+1})\,\Delta t_k\right].\tag{7}
\]

The quaternion on the right is the finite rotation of the interval expressed as a rotation vector; the product is on the **right** because angular velocity is expressed in the local OL frame. No ongoing OMC correction, reinitialization, or magnetometer heading correction was applied. Comparison used the angle of \(R_{\mathrm{OMC}}^T R_{\mathrm{IMU}}\).

### 2.6 Task 5(a): Linear kinematic estimation

The aligned accelerometer values are specific force, not inertial linear acceleration. Each was rotated into OG using the **time-varying quaternion-estimated** orientation, and gravity was removed **after** rotation:

\[
\mathbf a_{\mathrm{OG}}(t)=R_{\mathrm{OG}\leftarrow\mathrm{OL}}^{\mathrm{IMU}}(t)\mathbf f_{\mathrm{OL}}(t)
-\begin{bmatrix}0\\0\\9.8\end{bmatrix}\;\mathrm{m/s^2}.\tag{8}
\]

All three assigned 4th-order Butterworth band-pass filters—0.3–5 Hz, 0.5–7 Hz, and 1.1–10 Hz—were applied *after* global transformation and gravity removal, using zero-phase forward-backward filtering. Velocity and position followed cumulative trapezoidal integration. For each whole-record estimate, the initial velocity was assumed zero and the initial position was set to the OMC four-marker centroid. The OMC comparison point was the same marker centroid. The physical marker-centroid-to-IMU lever arm was unknown, so **the same physical point is approximated, not established**. The 3-D position error was computed as

\[
\mathrm{RMSE}=\sqrt{\frac1N\sum_{k=1}^N\left\|\mathbf p_{\mathrm{IMU},k}-\mathbf p_{\mathrm{OMC},k}\right\|^2}.\tag{9}
\]

Band-pass filtering suppresses slow drift but also removes genuine slow translation; zero-velocity updates, accelerometer-bias estimation, and endpoint corrections were not used.

### 2.7 Task 5(b): Motion-period-informed filtering

Only OMC centroid height was used to find a 30-s candidate segment with a concentrated periodic peak and meaningful vertical displacement. Within that segment, repeated same-foot height maxima were separated by approximately one *full cycle of the instrumented foot* (not one alternating left/right step). The median peak-to-peak interval gave \(T\), and \(f_0=1/T\). Because no separately documented spoken or metronome rhythm was supplied, its relation to the instructed cadence remains an assumption. The lower passband was set to \(0.3f_0\) and the upper cutoff to \(\max(3f_0,3\,\mathrm{Hz})\), capped at 10 Hz; a low cutoff retains the fundamental and a 3-Hz upper cutoff retains several vertical-motion harmonics. The 0.3–5 Hz baseline and the period-informed estimate were computed on **the same full record with otherwise identical processing**, then compared over the same 30-s segment.

## 3. Results

### 3.1 Task 1 results

The actual dataset contained **0 missing marker coordinates** among 60,806 frames × 4 markers. Fig. 1 shows only the controlled mask-and-reconstruct demonstration. In the partial 180–180.8-s mask, marker 1 reconstruction had 4.79 mm RMSE per coordinate across XYZ; in the complete 185–185.35-s mask, all-marker reconstruction had 2.68 mm mean vector RMSE. These different error definitions should not be compared as if identical.

![Fig. 1. Synthetic marker occlusions: blue observed, orange reconstructed, dashed withheld truth; Z in mm.](mobi311_results/task1/occlusion_demonstration.png)

*Fig. 1. Synthetic marker occlusion demonstration; the original recorded coordinates were complete.*

### 3.2 Task 2 results

The final numerical transform (rounded to five decimals), taking stored IMU channels to empirical OL coordinates, was

\[
M=\begin{bmatrix}
0.97292&0.23047&0.01744\\
-0.23009&0.97293&-0.02157\\
0.02194&-0.01697&-0.99962
\end{bmatrix},\quad \det(M)\approx-1.
\]

The proper mounting rotation between *already converted* right-handed ENU components and OL was

\[
Q=\begin{bmatrix}
0.97292&0.01744&0.23047\\
-0.23009&-0.02157&0.97293\\
0.02194&-0.99962&-0.01697
\end{bmatrix},\quad \det(Q)\approx+1.
\]

The raw gyro bias from the stationary 1–5-s interval was \((0.21592,0.02299,-0.81486)\) deg/s. In the approximate mapping, \(\omega_{\mathrm{OL},x}\approx+0.973\omega_{\mathrm{raw},x}+0.230\omega_{\mathrm{raw},y}+0.017\omega_{\mathrm{raw},z}\); \(\omega_{\mathrm{OL},y}\approx-0.230\omega_x+0.973\omega_y-0.022\omega_z\); and \(\omega_{\mathrm{OL},z}\approx+0.022\omega_x-0.017\omega_y-1.000\omega_z\), after raw bias subtraction and unit conversion. Thus the large terms retain raw X and Y signs, while local Z is approximately **negative raw Z**. The in-sample static gravity alignment residual was only 0.132°, but this is a fitted residual, not independent evidence of accuracy.

### 3.3 Task 3 results

The fitted affine clock parameters were \(\alpha=1.00421650\), \(\beta=-2.473879\) s, with angular-speed magnitude correlation \(r=0.971786\). The fitted scale differs from unity by approximately 0.42% over the record. Fig. 2 highlights the improvement near 280–291 s.

![Fig. 2. OMC and IMU angular speed before and after synchronization, rad/s.](mobi311_results/task3/synchronization.png)

*Fig. 2. OMC and IMU angular-speed magnitudes before and after affine time alignment.*

Using OMC times 120–600 s for a **post-hoc** test of the Task 2 calibration, the IMU-versus-OMC angular-velocity vector RMSE was **22.19 deg/s** and the median direction error during motions above 0.5 rad/s was **7.17°**. The reference OMC angular-velocity vector RMS was **102.29 deg/s**. As a sign-sensitivity check, reversing all three calibrated stored gyro signs increased the RMSE to **206.41 deg/s**, supporting the chosen operational channel polarity on this recording. These validation samples did not enter the fixed calibration fit; the clock fit did use the full recorded interval.

### 3.4 Task 4 results

The orientation error started at zero by the one-time OMC initialization. Its average during the first 30 s was **3.41°**; the whole-record mean was **89.95°**, and the final error was **165.12°**. Fig. 3 shows the ensuing large error accumulation.

![Fig. 3. Relative rotation-angle error, degrees.](mobi311_results/task4/orientation_error.png)

*Fig. 3. Relative IMU–OMC orientation error over the synchronized interval.*

### 3.5 Task 5(a) results

Table 1 summarizes the three assigned filter bands. These errors use the whole 608-s synchronized record and the marker-centroid position proxy.

**Table 1. Three-dimensional trajectory errors for fixed-band filters (mm).**

| Band-pass filter | Vector position RMSE (mm) | Final position error (mm) |
|:--|--:|--:|
| 0.3–5 Hz | 2238.50 | 1022.43 |
| 0.5–7 Hz | **2016.65** | 1197.94 |
| 1.1–10 Hz | 2309.55 | **473.01** |

The three trajectories are displayed separately in Figs. 4–6. The setting with the smallest final position error was not the setting with the smallest overall RMSE.

![Fig. 4. OMC vs IMU trajectory, 0.3–5 Hz.](mobi311_results/task5/trajectory_0.3_5Hz.png)

*Fig. 4. Task 5(a): position estimates with 0.3–5 Hz filtering.*

![Fig. 5. OMC vs IMU trajectory, 0.5–7 Hz.](mobi311_results/task5/trajectory_0.5_7Hz.png)

*Fig. 5. Task 5(a): position estimates with 0.5–7 Hz filtering.*

![Fig. 6. OMC vs IMU trajectory, 1.1–10 Hz.](mobi311_results/task5/trajectory_1.1_10Hz.png)

*Fig. 6. Task 5(a): position estimates with 1.1–10 Hz filtering.*

### 3.6 Task 5(b) results

The automatic OMC-height periodicity search selected **120–150 s**. The median interval between valid repeated same-foot maxima was \(T=1.565\) s; hence \(f_0=0.63898\) Hz. The resulting filter was **0.192–3.000 Hz**.

![Fig. 7. OMC centroid height and spectrum for the selected periodic interval.](mobi311_results/task5/period_selection.png)

*Fig. 7. Peak positions in the foot-mounted OMC centroid-height signal and its periodogram.*

**Table 2. Same-segment position RMSE in Task 5(b) (mm).**

| Estimate | Segment, OMC seconds | Vector position RMSE (mm) |
|:--|:--:|--:|
| Fixed 0.3–5 Hz | 120–150 | 2130.35 |
| Period informed 0.192–3 Hz | 120–150 | **2045.86** |

![Fig. 8. Same-period OMC and two IMU trajectories, mm.](mobi311_results/task5/period_comparison.png)

*Fig. 8. Task 5(b): trajectories on the identical 120–150-s segment. Differences include accumulated position offsets from earlier integration.*

## 4. Discussion

**Task 1.** Since the original OMC data contained no missing values, the reconstruction demonstration estimates behavior under *simulated* occlusion rather than historical recovery performance. A short complete gap can be interpolated, but a longer gap with turns or unmodeled acceleration may diverge. The fixed reference is empirical because measured marker-to-marker distances did not match the assignment’s illustrative nominal dimensions exactly. Marker-ID uncertainty prevents equating the software-defined positive OL axis with a physically labeled arrow on the plate without additional verification.

**Task 2 methodological validity.** The major separation is between the coordinate-order reflection \(C\) and proper mounting rotation \(Q\). Static gravity does not resolve yaw, so the wearing photograph provides a conditional second cue. The result is a transparent independent *candidate* fixed calibration, not a uniquely identified camera-to-board extrinsic calibration. An exact positive board axis, sensor API sign map, or an independently performed calibration movement would be needed for a hardware-verified result. The later 22.19-deg/s angular-velocity RMSE and 7.17° median direction error indicate substantial consistency under movement but also measurable residual misalignment, sensor error, OMC derivative noise, and possible soft-tissue/attachment motion. The much worse 206.41-deg/s error under an all-channel sign reversal supports, but does not prove at firmware level, the chosen recorded gyro polarity. The static 0.132° gravity fit by itself does not validate yaw or gyro channel signs. Motion-based IMU-to-MCS calibration is an established alternative [3], but if fitted using synchronized OMC angular velocities it must be described as **Task 3–4 verification/refinement**, not as an independently completed Task 2.

**Task 3.** The strong time-aligned angular-speed agreement supports the affine clock model. A single constant time shift would be less suitable if the approximate 0.42% fitted scale difference reflects timing mismatch. Because the fit used the full recording, the later spatial-check window is not a fully independent clock-validation set.

**Task 4.** The first 30 s showed reasonable agreement, but the full 10-minute quaternion integration had severe orientation drift. Angular velocity bias, residual mounting errors, gyro scale/misalignment, and integration noise accumulate, especially in the unconstrained heading component. No intermediate OMC feedback or magnetic correction was incorporated. A brief initial agreement must not be presented as long-term attitude accuracy.

**Task 5(a).** Of the specified bands, 0.5–7 Hz had the lowest whole-record RMSE, but all three produced meter-level errors and failed to reproduce the broad OMC horizontal translation. Raising the lower cutoff to 1.1 Hz suppresses step-cycle and slower translation components as well as low-frequency drift; the 0.3-Hz setting retains more slowly varying acceleration but can retain more bias-like components. Changing upper cutoff from 5 to 10 Hz allows more rapid foot-swing and impact components, but also more high-frequency noise. The large error is not solely a filter issue: the propagated orientation error causes gravity leakage into horizontal acceleration, and double integration creates position drift. The unknown lever arm and the assumed zero initial velocity further limit same-point validation.

**Task 5(b).** The OMC-derived period was based on the repeated height maxima of the *instrumented foot*, whose full cycle encompasses the return of that same foot to a comparable height phase. The selected 0.192–3 Hz band included the 0.639-Hz fundamental and several harmonics while discarding slower translation and sharper acceleration peaks. Its within-segment RMSE was approximately 84.50 mm (4.0%) below the 0.3–5 Hz fixed baseline; this modest comparison does **not** establish that it reconstructed the absolute walking trajectory accurately. Both estimates retained large offsets accumulated before the segment, and the selected period/rhythm was not confirmed against an external metronome record. A more meaningful further study would examine stride-relative displacement with explicit zero-velocity updates and a measured marker-centroid-to-IMU lever arm.

**Conclusion.** All five tasks were computed in the assignment order. Critically, Task 2 used only static gravity, the initial OMC plate pose, and a stated visual mounting hypothesis, so it did not leak the time synchronization from Task 3 into the claimed fixed calibration. Subsequent synchronization yielded strong angular-speed agreement, while quaternion and double-integrated acceleration estimates exhibited expected long-term drift. Numerical accuracy is limited by the incomplete physical calibration and IMU integration assumptions, not concealed by post-hoc refitting.

## References

[1] W. Kabsch, “A solution for the best rotation to relate two sets of vectors,” *Acta Crystallographica Section A*, vol. 32, no. 5, pp. 922–923, 1976. DOI: [10.1107/S0567739476001873](https://doi.org/10.1107/S0567739476001873).

[2] F. O. Silva, L. P. S. Paiva, and G. S. Carvalho, “Error Analysis of Accelerometer- and Magnetometer-Based Stationary Alignment,” *Sensors*, vol. 21, no. 6, article 2040, 2021. DOI: [10.3390/s21062040](https://doi.org/10.3390/s21062040).

[3] J. K. Lee and W. C. Jung, “Quaternion-Based Local Frame Alignment between an Inertial Measurement Unit and a Motion Capture System,” *Sensors*, vol. 18, no. 11, article 4003, 2018. DOI: [10.3390/s18114003](https://doi.org/10.3390/s18114003).

## Reproduction notes

Run `python mobi311_tasks_1_to_5.py` from the unpacked folder, retaining `upload/imu(3).csv` and `upload/omc_vicon.csv` at their recorded paths. The script writes all intermediate CSVs and graphics under `mobi311_results/task1` through `task5`, plus `mobi311_results/results_summary.json`. Unverified assumptions are encoded openly in the source; confirm exact marker labels/board-axis sign and the motion instruction before using the report as a final scientific claim. Replace the name and student-number placeholders and export the Markdown document to PDF in a local Markdown editor or other authorized document converter.
