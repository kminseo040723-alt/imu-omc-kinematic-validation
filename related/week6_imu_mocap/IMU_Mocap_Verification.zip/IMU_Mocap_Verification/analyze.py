from pathlib import Path
import json, base64, hashlib, shutil, zipfile
import numpy as np
import pandas as pd
from scipy.signal import butter, sosfiltfilt, welch
from scipy.integrate import cumulative_trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
SRC=OUT/'input' if (OUT/'input').is_dir() else ROOT/'upload'
u=np.loadtxt(SRC/'BC1imu_acc(2).csv',delimiter=',')
p=np.loadtxt(SRC/'BC1mc_pos(2).csv',delimiter=',')
supplied=np.loadtxt(SRC/'BC1rotm(2).csv',delimiter=',')
t=u[:,0]; ai=u[:,1:]; dt=np.diff(t); fs=1/dt.mean(); n=len(t)
assert u.shape==(2104,4) and p.shape==(2104,3)
assert np.isfinite(u).all() and np.isfinite(p).all() and (dt>0).all()
assert np.allclose(supplied.T@supplied,np.eye(3)) and np.isclose(np.linalg.det(supplied),1)
def rot(deg):
    q=np.deg2rad(deg);return np.array([[np.cos(q),-np.sin(q),0],[np.sin(q),np.cos(q),0],[0,0,1]])
def deriv(x):return np.gradient(x,t,axis=0,edge_order=2)
def filt(x,fc,kind='lowpass'):return sosfiltfilt(butter(4,fc,btype=kind,fs=fs,output='sos'),x,axis=0)
def integrate(x,initial):return cumulative_trapezoid(x,t,axis=0,initial=0)+initial
def yaw(x,y):
    b=x[:100,:2];a=y[:100,:2]
    return float(np.rad2deg(np.arctan2(np.sum(b[:,0]*a[:,1]-b[:,1]*a[:,0]),np.sum(b*a)))%360)
def metric(ref,pred,sl=slice(100,None)):
    a=ref[sl];b=pred[sl];e=b-a
    rm=np.sqrt(np.mean(e*e,axis=0));ma=np.mean(abs(e),axis=0)
    r2=1-np.sum(e*e,axis=0)/np.sum((a-a.mean(axis=0))**2,axis=0)
    c=np.array([np.corrcoef(a[:,j],b[:,j])[0,1] for j in range(3)])
    return {'rmse':rm,'mae':ma,'r2':r2,'corr':c,'vector_rmse':float(np.sqrt(np.mean(np.sum(e*e,axis=1))))}
vraw=deriv(p);araw=deriv(vraw)
primary_mc=filt(araw,15);primary_imu=filt(ai,15)
angle=yaw(primary_mc,primary_imu);R=rot(angle)
grid=np.arange(0,360,0.1)
cost=np.array([np.mean(np.sum((primary_mc[:100]@rot(q).T-primary_imu[:100])**2,axis=1)) for q in grid])
assert min(abs(grid[cost.argmin()]-angle),360-abs(grid[cost.argmin()]-angle))<0.11
provided_angle=float(np.rad2deg(np.arctan2(supplied[1,0],supplied[0,0]))%360)
rows=[];conditions={}
def condition(stage,fc):
    pp=filt(p,fc) if stage in ('pre','both') else p.copy()
    vv=deriv(pp);aa=deriv(vv)
    if stage in ('post','both'): vv=filt(vv,fc);aa=filt(aa,fc)
    ii=filt(ai,fc) if stage!='none' else ai.copy()
    return pp,vv,aa,ii
for stage,fc in [('none',None)]+[(s,f) for f in (5,10,15,20,30) for s in ('pre','post','both')]:
    pp,vv,aa,ii=condition(stage,fc);q=yaw(aa,ii)
    for policy,degrees in [('fixed_primary_yaw',angle),('own_first100_yaw',q)]:
        rr=rot(degrees);pr=pp@rr.T;vr=vv@rr.T;ac=aa@rr.T
        vi=integrate(ii,vr[0]);pi=integrate(vi,pr[0])
        for quantity,ref,pred in [('acceleration',ac,ii),('velocity',vr,vi),('position',pr,pi)]:
            m=metric(ref,pred)
            row={'stage':stage,'cutoff_hz':fc,'yaw_policy':policy,'yaw_deg_mc_to_imu':degrees,'quantity':quantity,'evaluation':'samples_101_end','vector_rmse':m['vector_rmse']}
            for key in ('rmse','mae','r2','corr'):
                for j,axis in enumerate('xyz'):row[f'{key}_{axis}']=m[key][j]
            rows.append(row)
    conditions[(stage,fc)]=(pp,vv,aa,ii)
metrics=pd.DataFrame(rows);metrics.to_csv(OUT/'filter_metrics.csv',index=False,encoding='utf-8-sig')
case_dir=OUT/'filter_cases';case_dir.mkdir(exist_ok=True)
for (stage,fc),(case_p,case_v,case_a,case_i) in conditions.items():
    case_series={'sample_1based':np.arange(1,n+1),'time_s':t}
    for name,arr in [('mocap_position',case_p@R.T),('mocap_velocity',case_v@R.T),('mocap_acceleration',case_a@R.T),('imu_acceleration',case_i)]:
        for j,ax in enumerate('xyz'):case_series[name+'_'+ax]=arr[:,j]
    pd.DataFrame(case_series).to_csv(case_dir/f'{stage}_{fc or "no_cutoff"}Hz.csv',index=False)
pp,vv,aa,ii=conditions[('post',15)]
pr=pp@R.T;vr=vv@R.T;ac=aa@R.T
vi=integrate(ii,vr[0]);pi=integrate(vi,pr[0])
assert np.allclose(vi[0],vr[0]) and np.allclose(pi[0],pr[0])
series={'sample_1based':np.arange(1,n+1),'time_s':t,'is_calibration':np.arange(n)<100}
for name,arr in [('imu_acc_raw',ai),('imu_acc_lp15',ii),('mocap_pos_common',pr),('mocap_vel_common',vr),('mocap_acc_raw_common',araw@R.T),('mocap_acc_lp15_common',ac),('imu_vel_integrated',vi),('imu_pos_integrated',pi)]:
    for j,axis in enumerate('xyz'):series[name+'_'+axis]=arr[:,j]
pd.DataFrame(series).to_csv(OUT/'processed_timeseries.csv',index=False,encoding='utf-8-sig')
pd.DataFrame({'yaw_deg_mc_to_imu':grid,'calibration_sse':cost*100}).to_csv(OUT/'yaw_search.csv',index=False)
rotation_rows=[]
for label,q in [('identity',0),('first100_SSE',angle),('supplied_matrix',provided_angle),('discussion_example_direct',292.8),('discussion_example_inverse',67.2)]:
    pred=aa@rot(q).T
    for scope,sl in [('calibration_1_100',slice(0,100)),('validation_101_end',slice(100,None)),('all_samples',slice(None))]:
        for refname,ref,target in [('mocap',pred,ii),('imu',ii,pred)]:
            m=metric(ref,target,sl);row={'rotation':label,'yaw_deg':q,'scope':scope,'r2_reference':refname,'vector_rmse':m['vector_rmse']}
            for key in ('rmse','r2','corr'):
                for j,ax in enumerate('xyz'):row[f'{key}_{ax}']=m[key][j]
            rotation_rows.append(row)
pd.DataFrame(rotation_rows).to_csv(OUT/'rotation_validation.csv',index=False,encoding='utf-8-sig')
filter_changes=[]
for name,raw in [('mocap_position',p),('mocap_acceleration',araw),('imu_acceleration',ai)]:
    filtered=filt(raw,15);e=filtered-raw
    for j,ax in enumerate('xyz'):
        filter_changes.append({'signal':name,'axis':ax,'filter_change_rmse':np.sqrt(np.mean(e[100:,j]**2)),'change_over_raw_std_pct':100*np.sqrt(np.mean(e[100:,j]**2))/np.std(raw[100:,j])})
pd.DataFrame(filter_changes).to_csv(OUT/'filter_effect.csv',index=False,encoding='utf-8-sig')
hp=filt(ii,.1,'highpass');vh=integrate(hp,vr[0]);ph=integrate(vh,pr[0])
hp_rows=[]
for name,acc,vel,pos in [('LP15_only',ii,vi,pi),('LP15_HP0.1_exploratory',hp,vh,ph)]:
    for quant,ref,pred in [('acceleration',ac,acc),('velocity',vr,vel),('position',pr,pos)]:
        m=metric(ref,pred);hp_rows.append({'method':name,'quantity':quant,'vector_rmse':m['vector_rmse'],'final_vector_error':float(np.linalg.norm(pred[-1]-ref[-1]))})
pd.DataFrame(hp_rows).to_csv(OUT/'highpass_exploratory.csv',index=False)
# Derivative-method sensitivity: does the PPT's rounded RMSE reproduce?
sensitivity=[]
for mode in ('timestamp_gradient','mean_dt_gradient','forward_diff','backward_diff'):
    if mode=='timestamp_gradient':b=deriv(deriv(p))
    elif mode=='mean_dt_gradient':b=np.gradient(np.gradient(p,dt.mean(),axis=0),dt.mean(),axis=0)
    else:
        z=np.diff(p,n=2,axis=0)/dt.mean()**2
        b=np.vstack([z,z[-1:],z[-1:]]) if mode=='forward_diff' else np.vstack([z[:1],z[:1],z])
    b=filt(b,15);q=yaw(b,ii)
    for lab,degrees in [('calibrated',q),('supplied',provided_angle),('example',292.8)]:
        before=metric(ii,b)['rmse'];after=metric(ii,b@rot(degrees).T)['rmse']
        row={'derivative':mode,'angle_source':lab,'yaw_deg':degrees}
        for j,ax in enumerate('xyz'):row['before_'+ax]=before[j];row['after_'+ax]=after[j]
        sensitivity.append(row)
pd.DataFrame(sensitivity).to_csv(OUT/'reproduction_sensitivity.csv',index=False)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
COL=['#2563eb','#ef6a31']; figs=[]
def save(fig,name):
    fig.savefig(OUT/name,bbox_inches='tight',facecolor='white');plt.close(fig);figs.append(name)
def axesplot(ref,pred,title,unit,name):
    fig,axs=plt.subplots(3,1,figsize=(11,7),sharex=True)
    for j,ax in enumerate(axs):
        ax.plot(t,ref[:,j],label='Mocap reference',color=COL[0],lw=1.2)
        ax.plot(t,pred[:,j],label='IMU estimate',color=COL[1],lw=1,alpha=.9)
        ax.axvspan(t[0],t[99],color='#999',alpha=.15);ax.set_ylabel('XYZ'[j]+' ['+unit+']');ax.grid(alpha=.2)
    axs[0].legend(loc='upper right',ncol=2);axs[-1].set_xlabel('Time [s]');fig.suptitle(title);fig.tight_layout();save(fig,name)
axesplot(ac,ii,'Acceleration: LP15, yaw calibrated on samples 1-100','m/s2','03_acceleration.png')
axesplot(vr,vi,'Velocity: initial velocity matched; no drift correction','m/s','04_velocity.png')
axesplot(pr-pr[0],pi-pi[0],'Position: equal initial position; no drift correction','m','05_position.png')
fig,axs=plt.subplots(3,2,figsize=(12,8),sharex=True)
for j in range(3):
    axs[j,0].plot(t,p[:,j],label='Raw');axs[j,0].plot(t,filt(p,15)[:,j],label='LP15',ls='--');axs[j,0].set_ylabel('XYZ'[j]+' position [m]')
    axs[j,1].plot(t,araw[:,j],label='Raw',alpha=.6);axs[j,1].plot(t,primary_mc[:,j],label='LP15');axs[j,1].set_ylabel('XYZ'[j]+' acceleration [m/s2]')
    for ax in axs[j]:ax.grid(alpha=.2)
axs[0,0].legend();axs[0,1].legend();axs[-1,0].set_xlabel('Time [s]');axs[-1,1].set_xlabel('Time [s]')
fig.suptitle('Filtering can barely change position, yet change derived acceleration');fig.tight_layout();save(fig,'01_filter_effect.png')
fig,axs=plt.subplots(1,2,figsize=(12,4))
axs[0].plot(grid,cost);axs[0].axvline(angle,color=COL[1],label=f'SSE optimum {angle:.2f} deg');axs[0].axvline(provided_angle,color='green',ls='--',label=f'Supplied {provided_angle:.2f} deg');axs[0].legend();axs[0].set_xlabel('Yaw [deg]');axs[0].set_ylabel('Calibration mean squared vector error')
freq,psd=welch(araw,fs=fs,axis=0,nperseg=512)
for j in range(3):axs[1].semilogy(freq,psd[:,j],label='XYZ'[j])
axs[1].axvline(15,color='black',ls='--');axs[1].legend();axs[1].set_xlabel('Frequency [Hz]');axs[1].set_ylabel('Mocap acceleration PSD')
fig.tight_layout();save(fig,'02_yaw_psd.png')
fig,axs=plt.subplots(1,2,figsize=(12,4))
base=metrics[(metrics.quantity=='acceleration')&(metrics.yaw_policy=='fixed_primary_yaw')]
for s in ('pre','post','both'):
    z=base[base.stage==s];axs[0].plot(z.cutoff_hz,z.vector_rmse,'o-',label=s)
axs[0].axhline(base[base.stage=='none'].vector_rmse.iloc[0],ls='--',color='gray',label='no filter');axs[0].legend();axs[0].set_xlabel('Cutoff [Hz]');axs[0].set_ylabel('Acceleration vector RMSE [m/s2]')
axs[1].plot(t,np.linalg.norm(pi-pr,axis=1),label='LP15 only');axs[1].plot(t,np.linalg.norm(ph-pr,axis=1),label='LP15 + HP0.1 (exploratory)');axs[1].legend();axs[1].set_xlabel('Time [s]');axs[1].set_ylabel('Position vector error [m]')
fig.tight_layout();save(fig,'06_cutoff_highpass.png')
fig,ax=plt.subplots(figsize=(7,5));ax.plot(pr[:,0]-pr[0,0],pr[:,1]-pr[0,1],label='Mocap');ax.plot(pi[:,0]-pi[0,0],pi[:,1]-pi[0,1],label='IMU integration');ax.set_xlabel('X displacement [m]');ax.set_ylabel('Y displacement [m]');ax.set_aspect('equal',adjustable='datalim');ax.legend();ax.grid(alpha=.2);save(fig,'07_xy_trajectory.png')
before=metric(ii,aa)['rmse'];after=metric(ii,ac)['rmse'];m=metric(ac,ii)
report={'samples':n,'duration_s':float(t[-1]-t[0]),'mean_sampling_hz':fs,'dt_min_s':float(dt.min()),'dt_max_s':float(dt.max()),'yaw_first100_deg':angle,'yaw_supplied_deg':provided_angle,'rmse_before':before.tolist(),'rmse_after':after.tolist(),'r2_mocap_reference':m['r2'].tolist(),'correlation':m['corr'].tolist(),'final_velocity_error':float(np.linalg.norm(vi[-1]-vr[-1])),'final_position_error':float(np.linalg.norm(pi[-1]-pr[-1])),'velocity_rmse':metric(vr,vi)['rmse'].tolist(),'position_rmse':metric(pr,pi)['rmse'].tolist(),'filter_effect':filter_changes,'highpass':hp_rows}
(OUT/'results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def table(df):return df.to_html(index=False,float_format=lambda x:f'{x:.5f}',border=0)
def img(name):return '<img src="data:image/png;base64,'+base64.b64encode((OUT/name).read_bytes()).decode()+'">'
rt=pd.DataFrame({'axis':list('XYZ'),'before_rmse':before,'after_rmse':after,'R2_mocap_reference':m['r2'],'correlation':m['corr']})
checks=pd.DataFrame([
    ['Sample duration',21.26,float(t[-1]),'Consistent after rounding'],
    ['Sampling rate Hz',98.9,fs,'Consistent after rounding'],
    ['Yaw example deg',292.8,angle,'Not reproduced by first100 SSE'],
    ['Supplied matrix yaw deg',291.810584958,provided_angle,'Verified directly from matrix'],
    ['PPT X RMSE before',1.46,before[0],'Not exactly reproduced'],
    ['PPT X RMSE after',.73,after[0],'Not exactly reproduced'],
    ['PPT Y RMSE before',1.37,before[1],'Not exactly reproduced'],
    ['PPT Y RMSE after',.72,after[1],'Not exactly reproduced'],
    ['PPT Z RMSE',.80,after[2],'Not exactly reproduced'],
    ['Discussion X R2',.80,m['r2'][0],'Approximately consistent'],
    ['Discussion Z R2',.90,m['r2'][2],'Similar trend; not exact reproduction'],
],columns=['claim','reported','recomputed_primary','status'])
checks.to_csv(OUT/'claim_verification.csv',index=False,encoding='utf-8-sig')
summary=f'''<h1>IMU–Mocap CSV 검증 결과</h1><p>2,104 samples · 21.2566 s · {fs:.5f} Hz. IMU GLOBAL frame을 공통 기준으로 사용했습니다. Gravity-compensated acceleration이라는 Discussion 가정을 적용하며 중력을 다시 빼지 않습니다.</p>
<h2>계산 조건</h2><p>주 분석: 실제 Timestamp 기반 central finite differences(np.gradient, edge_order=2), Mocap Velocity/Acceleration 미분 후 4th-order Butterworth 15 Hz Low-pass, IMU도 동일 Low-pass. Offline zero-phase sosfiltfilt 적용. Timestamp는 약간 불균일하지만 평균 Sampling rate로 Filter를 설계했으며 Resampling하지 않았습니다. Sample 1–100만 사용해 SSE 최소 Yaw를 계산하고, 101–end에서 평가합니다. 각 축을 별도로 최적화하지 않았고, Bias/Scale/Time offset을 결과에 맞춰 조정하지 않았습니다.</p>
<p>Yaw: {angle:.5f}° (Mocap → IMU). 반대 변환은 {(360-angle)%360:.5f}°. 제공 Matrix의 Yaw는 {provided_angle:.5f}°. Matrix의 적용 방향은 파일 자체에 명시되지 않아, 위 Yaw는 열벡터에 곱할 때의 Matrix 각도입니다. 같은 두 frame의 반대 변환을 사용할 때에는 반드시 transpose를 사용합니다.</p>
<h2>Acceleration 비교</h2>{table(rt)}<p>RMSE 단위 m/s². R²의 Reference는 Mocap입니다. Correlation²과 R²는 서로 다른 지표이며, 서로 바꾸어 적으면 안 됩니다. rotation_validation.csv에는 두 Reference 방향의 R²를 모두 담았습니다. Yaw만 바꾸므로 Z RMSE가 유지되는 것은 정상입니다.</p>
<h2>다른 사람·제공 자료의 값 검증</h2>{table(checks)}<p>스크린샷에는 수치 계산 코드가 없으므로 PPT의 X 1.46→0.73, Y 1.37→0.72, Z 0.80→0.80 및 Discussion 예시값을 검증했습니다. 현재 조건으로 수치가 정확히 재현되지는 않았습니다. Timestamp/평균 dt, finite difference 방식, Boundary treatment, Filter 대상, Rotation angle, 평가 구간이 다르면 값이 달라집니다. reproduction_sensitivity.csv에 비교를 기록했습니다. 일치하지 않는다는 것만으로 타인의 계산 오류를 확정할 수는 없습니다.</p>
<p>Discussion의 292.8°와 R²≈0.80/0.90는 참고 예시이며 유일한 정답이 아닙니다. 292.8°를 직접 적용한 경우와 반대 방향 67.2°를 모두 rotation_validation.csv에 기록했습니다. 제공 Matrix의 291.81°와도 0.99° 차이가 있습니다.</p>
<h2>Filtering이 거의 변화가 없다는 주장</h2>{table(pd.DataFrame(filter_changes))}<p>Position은 이미 매끄러워 변화가 작을 수 있지만, 이것만으로 사전 Filtering 여부를 판단할 수 없습니다. 유한 차분도 Nyquist 부근 Noise를 억제할 수 있습니다. Noise가 모든 주파수에 있을 수 있고 실제 움직임도 고주파 성분을 포함하므로, Signal=low frequency / Noise=high frequency는 단순화입니다.</p>
<h2>Cutoff·Filter 위치 비교</h2>{table(base[['stage','cutoff_hz','vector_rmse','rmse_x','rmse_y','rmse_z']])}<p>위 표는 모든 조건에서 주 분석 Yaw를 고정해 Filtering 효과를 분리했습니다. filter_metrics.csv에는 각 조건마다 first100 Calibration을 다시 한 결과도 있습니다. pre=Position Filtering 후 미분, post=원본 Position 미분 후 Velocity/Acceleration Filtering, both=양쪽에 적용. both는 Filter 전달함수가 중복 적용되어 같은 nominal Cutoff라도 효과가 다릅니다. 모든 Filter 조건에서 IMU도 동일 Cutoff로 Filtering합니다. RMSE가 가장 작은 Cutoff를 101–end에서 고르는 것은 Test data에 대한 선택이므로 검증 성능으로 과장하지 않습니다. 15 Hz는 제공 예시에 맞춘 Baseline이며, PSD와 여러 Cutoff의 Peak/Timing 보존을 함께 확인하세요.</p>
<h2>Integration과 Drift</h2><p>IMU Velocity의 Initial value는 처리된 Mocap Velocity의 첫 값, Position은 회전된 Mocap 첫 Position과 맞췄습니다. 이는 비교를 위한 Reference initial condition이며 독립적인 IMU 위치 추정 성능이 아닙니다. Trapezoidal integration, 전체 기록에서 시작하며 첫 100개를 적분에서 제거하지 않았습니다. 최종 Velocity vector error={report['final_velocity_error']:.4f} m/s, 최종 Position vector error={report['final_position_error']:.4f} m. Low-pass만으로 Bias/Drift가 제거되지 않습니다.</p>
<p>상수 Acceleration error b이면 Velocity error=bt, Position error=½bt². High-pass는 DC 및 저주파 성분을 줄이지만, 실제 지속적 Acceleration도 제거하며 Initial velocity error와 Boundary transient는 남습니다. HP0.1 Hz 결과는 선택하지 않은 참고 실험이고 Drift 제거를 보장하지 않습니다.</p>{table(pd.DataFrame(hp_rows))}
<h2>발표에 적용할 수정</h2><ol><li>IMU는 이미 GLOBAL frame이라고 명시하고 Mocap을 그 frame으로 변환합니다.</li><li>Rotation 선택 기준을 first100 SSE minimum으로 통일합니다.</li><li>Filtering 페이지에는 Position과 derived Acceleration 전후 그래프 및 Cutoff 비교를 넣습니다.</li><li>Coordinate conversion 페이지에는 first100 Calibration과 101–end 평가를 구분하고 위 검증 RMSE를 계산 조건과 함께 표시합니다.</li><li>Velocity·Position 비교 페이지에는 공통 Initial conditions와 Drift 결과를 넣습니다.</li><li>“Low-pass fixes noise, high-pass fixes bias” 대신 “Low-pass reduces high-frequency components; High-pass attenuates DC/low-frequency components but can remove real motion”이라고 수정합니다.</li><li>Conclusion에는 Yaw-only 가정, sensor-marker 위치 차이, Integration drift, Mocap도 완전한 Ground truth가 아니라는 한계를 넣습니다.</li></ol>
<h2>자료·재현</h2><p>Sources: BC1imu_acc(2).csv, BC1mc_pos(2).csv, BC1rotm(2).csv; IMU_Mocap_Flowchart_(2).pptx slides 1/3/4; Week6_Signal_Processing_Discussion(2).docx sections C4/C5/C6/D; 센서이론_7주차(1).pptx slides 5/10; two attached screenshots. No unprovided team code was assumed.</p><p>CSV는 Header 없는 원본을 np.loadtxt로 읽었으며 첫 Sample을 빠뜨리지 않았습니다. analyze.py와 input/ 원본을 포함했습니다. 필요한 Python packages: numpy pandas scipy matplotlib reportlab. python analyze.py로 재계산할 수 있습니다.</p>'''
html='<!doctype html><html lang="ko"><meta charset="utf-8"><title>IMU Mocap verification</title><style>body{max-width:1120px;margin:40px auto;padding:0 24px;font-family:Arial,"Malgun Gothic",sans-serif;line-height:1.7;color:#14243a}h1{font-size:32px}h2{margin-top:40px;color:#195ec0}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3fc}img{width:100%;margin:24px 0}p{max-width:1000px}</style><body>'+summary+''.join('<h2>'+name+'</h2>'+img(name) for name in figs)+'</body></html>'
html=html.replace('<h2>Acceleration 비교</h2>','<p>Zero-phase Filtering은 미래 Sample도 참조합니다. 따라서 Calibration 목적함수는 처음 100개에서만 계산했지만 전처리된 Calibration 값에는 인접한 이후 Sample의 영향이 있습니다. 이는 Offline 전체 기록 분석이며 엄격한 Causal held-out 검증은 아닙니다.</p><h2>Acceleration 비교</h2>')
(OUT/'report.html').write_text(html,encoding='utf-8')
# English PDF for portable figures; the full Korean interpretation is in report.html.
c=canvas.Canvas(str(OUT/'report.pdf'),pagesize=(842,595))
c.setTitle('IMU Mocap CSV verification')
def line(text,y,size=12):c.setFont('Helvetica',size);c.drawString(40,y,text)
line('IMU / Mocap: CSV verification',548,24)
for k,txt in enumerate([
    f'2104 samples | duration 21.2566 s | mean sample rate {fs:.5f} Hz',
    'Common frame: IMU GLOBAL. Mocap rotated into this frame. Gravity compensated by assumption.',
    'Timestamp-based gradient, edge_order=2. Fourth-order Butterworth LP15, offline zero phase.',
    'Mocap velocity/acceleration filtered after differentiation; IMU acceleration also filtered.',
    f'First100 SSE yaw: {angle:.5f} deg. Supplied matrix yaw: {provided_angle:.5f} deg.',
    'Evaluation: samples 101-end. No test-set angle refitting, bias adjustment or time shift.',
    'Axis      Acceleration RMSE before -> after [m/s2]       R2 (Mocap reference)',
    *[f'{ax}               {before[j]:.5f} -> {after[j]:.5f}                         {m["r2"][j]:.5f}' for j,ax in enumerate('XYZ')],
    f'Final velocity vector error: {report["final_velocity_error"]:.4f} m/s',
    f'Final position vector error: {report["final_position_error"]:.4f} m',
    'Initial velocity/position matched to Mocap. This is reference-aided initialization.',
    'Team PPT rounded RMSE not exactly reproduced; unknown original code prevents error attribution.',
    '15 Hz is a baseline from the Discussion, not a uniquely optimal cutoff.',
    'Full Korean interpretation, formulas, all case metrics and reproducible code: report.html / CSV files.',
]):line(txt,500-k*25,11)
c.showPage()
for name in figs:
    line(name.replace('_',' ').replace('.png',''),556,18)
    im=ImageReader(str(OUT/name));w,h=im.getSize();scale=min(762/w,475/h);c.drawImage(im,(842-w*scale)/2,50,w*scale,h*scale)
    c.setFont('Helvetica',9);c.drawString(40,22,'Source: attached BC1 CSV data. See report.html for assumptions and interpretation.');c.showPage()
c.save()
pd.DataFrame([{'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in SRC.glob('*(2).csv')]).to_csv(OUT/'source_hashes.csv',index=False)
inp=OUT/'input';inp.mkdir(exist_ok=True)
for name in ['BC1imu_acc(2).csv','BC1mc_pos(2).csv','BC1rotm(2).csv']:
    if (SRC/name).resolve()!=(inp/name).resolve():shutil.copy2(SRC/name,inp/name)
print(json.dumps(report,indent=2))
