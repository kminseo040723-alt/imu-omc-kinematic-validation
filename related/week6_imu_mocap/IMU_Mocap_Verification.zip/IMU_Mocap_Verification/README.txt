압축 해제 후 report.html을 브라우저로 여세요. 한글 해석, 검증표, 모든 그래프가 들어 있습니다.
report.pdf: 요약과 그래프 8페이지.
filter_metrics.csv: 16개 Filtering 조건, 고정/개별 Yaw, Acceleration/Velocity/Position 지표.
filter_cases/: 각 Filtering 조건의 Time series 16개 CSV (공통 Yaw 286.906도).
rotation_validation.csv: 제공 Matrix, Discussion 각도, SSE Calibration 비교 및 R2 Reference 방향.
processed_timeseries.csv: 주 분석 15 Hz 처리와 Integration 결과.
claim_verification.csv: 기존 자료 수치와 계산값 검증.
reproduction_sensitivity.csv: 미분 방식에 따른 재현 비교.
highpass_exploratory.csv: HP0.1 Hz 참고 실험.
analyze.py와 input/: 재현 코드와 원본 CSV. 필요한 라이브러리는 report.html에 명시했습니다.
