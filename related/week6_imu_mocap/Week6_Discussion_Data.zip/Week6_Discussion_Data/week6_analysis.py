"""Week 6: Discussion convention: IMU -> Mocap frame, minimum squared error.
Run: python week6_analysis.py
Dependencies: numpy scipy matplotlib
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
from scipy.signal import butter, sosfiltfilt
from scipy.integrate import cumulative_trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def rotation(deg):
    c, s = np.cos(np.deg2rad(deg)), np.sin(np.deg2rad(deg))
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.]])


def correlation(x, y):
    x, y = x-x.mean(), y-y.mean()
    denominator = np.linalg.norm(x)*np.linalg.norm(y)
    return float(x@y/denominator) if denominator > 1e-12 else float('nan')


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=root/'data')
    parser.add_argument('--out', type=Path, default=root/'results')
    parser.add_argument('--cutoff', type=float, default=15.)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    # 1번 담당: 파일 확인. Header가 없는 CSV이므로 첫 행도 데이터입니다.
    imu = np.loadtxt(args.data/'BC1imu_acc.csv', delimiter=',')
    pos = np.loadtxt(args.data/'BC1mc_pos.csv', delimiter=',')
    if imu.ndim != 2 or imu.shape[1] != 4 or pos.shape != (len(imu), 3):
        raise ValueError('Expected IMU N x 4, Mocap N x 3.')
    if not (np.isfinite(imu).all() and np.isfinite(pos).all()):
        raise ValueError('Non-finite input values.')
    original_t = imu[:, 0]-imu[0, 0]
    if not np.all(np.diff(original_t) > 0) or len(imu) <= 100:
        raise ValueError('Need increasing timestamps and more than 100 samples.')
    # PPT가 제공한 row synchronization을 가정합니다. 새 time lag를 추정하지 않습니다.
    t = np.linspace(0, original_t[-1], len(imu))
    dt = t[1]-t[0]
    fs = 1/dt
    if not 0 < args.cutoff < fs/2:
        raise ValueError('Cutoff must be between 0 and Nyquist frequency.')
    resample = lambda x: np.column_stack([np.interp(t, original_t, x[:, j]) for j in range(3)])
    acc = resample(imu[:, 1:])
    p = resample(pos)
    sos = butter(4, args.cutoff, fs=fs, output='sos')
    lowpass = lambda x: sosfiltfilt(sos, x, axis=0)
    derivative = lambda x: np.gradient(x, dt, axis=0, edge_order=2)

    # 2번 담당: Position prefilter -> 두 번 미분. IMU에도 같은 LPF 적용.
    pf = lowpass(p)
    vm = derivative(pf)
    am = derivative(vm)
    raw_am = derivative(derivative(p))
    ai = lowpass(acc)

    # 1번 담당: 원본의 처음 100행만 별도로 처리하여 Calibration에 사용.
    # 전체 신호의 zero-phase filter가 미래 구간을 사용하는 leakage를 피합니다.
    tc = np.linspace(original_t[0], original_t[99], 100)
    dc = tc[1]-tc[0]
    sc = butter(4, args.cutoff, fs=1/dc, output='sos')
    interp_cal = lambda x: np.column_stack([np.interp(tc, original_t[:100], x[:100, j]) for j in range(3)])
    pc = sosfiltfilt(sc, interp_cal(pos), axis=0)
    ac = sosfiltfilt(sc, interp_cal(imu[:, 1:]), axis=0)
    mc = np.gradient(np.gradient(pc, dc, axis=0, edge_order=2), dc, axis=0, edge_order=2)
    angles = np.arange(0, 360, 0.1)
    scores = []
    for angle in angles:
        candidate = ac @ rotation(angle).T  # row vectors: R a -> A R^T
        scores.append(np.sum((candidate-mc)**2))
    scores = np.asarray(scores)
    if not np.isfinite(scores).any():
        raise ValueError('Insufficient horizontal excitation for yaw calibration.')
    angle = float(angles[np.nanargmin(scores)])
    R = rotation(angle)
    pm = pf
    ai = ai @ R.T
    raw_ai = acc @ R.T
    # 회전은 IMU에만 적용합니다. Mocap Position은 원래 Frame을 유지합니다.
    np.savetxt(args.out/"estimated_rotation_imu_to_mocap.csv", R, delimiter=",")
    np.savetxt(args.out/"yaw_objective.csv", np.column_stack([angles, scores]), delimiter=",", header="yaw_deg,squared_error_sum", comments="")
    # Closed-form yaw 최소점과 grid search의 일치 확인.
    exact = np.rad2deg(np.arctan2(np.sum(ac[:,0]*mc[:,1]-ac[:,1]*mc[:,0]), np.sum(ac[:,:2]*mc[:,:2]))) % 360
    assert abs((angle-exact+180)%360-180) <= 0.051
    # 3번 담당: gravity-compensated linear acceleration이라는 과제 가정.
    # 초기조건을 Mocap에서 가져왔으므로 독립적인 위치 추정 검증은 아닙니다.
    vi = vm[0] + cumulative_trapezoid(ai, t, axis=0, initial=0)
    pi = pm[0] + cumulative_trapezoid(vi, t, axis=0, initial=0)
    # Bias removal, detrending, endpoint fitting, ZUPT를 적용하지 않습니다.

    rows = []
    for quantity, reference, estimate in [('acceleration', am, ai), ('velocity', vm, vi), ('position', pm, pi)]:
        for segment, mask in [('calibration_time', t <= original_t[99]), ('evaluation', t >= original_t[100])]:
            for j, axis in enumerate('XYZ'):
                y, yhat = reference[mask, j], estimate[mask, j]
                error = yhat-y
                sst = np.sum((y-y.mean())**2)
                rows.append(dict(quantity=quantity, segment=segment, axis=axis,
                                 RMSE=float(np.sqrt(np.mean(error**2))),
                                 MAE=float(np.mean(np.abs(error))),
                                 R2=float(1-np.sum(error**2)/sst) if sst > 1e-15 else float('nan'),
                                 correlation=correlation(y, yhat)))
    with (args.out/'metrics.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    plt.rcParams.update({'font.size': 10, 'axes.grid': True, 'grid.alpha': .2})
    def compare(filename, title, y1, y2, labels, unit):
        fig, axes = plt.subplots(3, 1, figsize=(11, 7), sharex=True, constrained_layout=True)
        for j, ax in enumerate(axes):
            ax.plot(t, y1[:, j], label=labels[0], lw=1.1, color='#176bba')
            ax.plot(t, y2[:, j], label=labels[1], lw=1.0, alpha=.85, color='#d65f24')
            ax.axvspan(0, original_t[99], color='grey', alpha=.13)
            ax.set_ylabel(f'{"XYZ"[j]} ({unit})')
        axes[0].legend(loc='upper right', ncol=2)
        axes[-1].set_xlabel('Time (s); shaded interval = calibration')
        fig.suptitle(title+' | Mocap global frame')
        fig.savefig(args.out/filename, dpi=160); plt.close(fig)
    compare('01_filter_effect.png', 'Mocap acceleration: effect of position prefiltering', raw_am, am,
            ['Raw position differentiated twice', f'{args.cutoff:g} Hz prefilter then derivatives'], 'm/s²')
    compare('02_acceleration.png', 'Acceleration comparison', am, ai, ['Mocap reference', 'IMU'], 'm/s²')
    compare('03_velocity.png', 'Velocity comparison: one IMU integration', vm, vi, ['Mocap reference', 'IMU integrated'], 'm/s')
    compare('04_position.png', 'Position comparison: two IMU integrations', pm, pi, ['Mocap reference', 'IMU integrated'], 'm')
    fig, ax = plt.subplots(figsize=(10, 4), constrained_layout=True)
    ax.plot(angles, scores); ax.axvline(angle, color='#d65f24', label=f'Selected yaw = {angle} deg')
    ax.set(xlabel='IMU -> Mocap yaw (deg)', ylabel='Sum of squared acceleration errors', title='Calibration: first 100 original samples only')
    ax.legend(); fig.savefig(args.out/'05_yaw_search.png', dpi=160); plt.close(fig)
    # 동일한 축척으로 Trajectory를 비교하여 Drift를 그대로 표시합니다.
    fig = plt.figure(figsize=(8, 7), constrained_layout=True)
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(*pm.T, label='Mocap'); ax.plot(*pi.T, label='IMU integrated')
    both = np.vstack([pm, pi]); center = (both.max(0)+both.min(0))/2
    radius = max(np.ptp(both, axis=0).max()/2, .01)
    ax.set_xlim(center[0]-radius, center[0]+radius); ax.set_ylim(center[1]-radius, center[1]+radius); ax.set_zlim(center[2]-radius, center[2]+radius)
    ax.set_box_aspect((1,1,1)); ax.set(xlabel='X (m)', ylabel='Y (m)', zlabel='Z (m)', title='3D trajectory | Mocap global frame'); ax.legend()
    fig.savefig(args.out/'06_trajectory_3d.png', dpi=160); plt.close(fig)
    # 필터 담당자가 바로 사용할 수 있는 원본/처리 후 동일 Frame 데이터.
    filter_arrays = np.column_stack([t, raw_am, am, raw_ai, ai])
    filter_header = 'time_s,'+','.join(f'{name}_{axis}_m_s2' for name in ['mocap_a_raw','mocap_a_filtered','imu_a_raw','imu_a_filtered'] for axis in 'xyz')
    np.savetxt(args.out/'filter_comparison.csv', filter_arrays, delimiter=',', header=filter_header, comments='')
    compare('07_imu_filter_effect.png', 'IMU acceleration before and after filtering', raw_ai, ai, ['Before LPF', 'After LPF'], 'm/s²')
    # Cutoff sensitivity: 고정된 15 Hz calibration angle로 비교; 최적 cutoff 선정용 정답은 아님.
    cutoff_rows = []
    for cutoff in [5., 10., 15., 20.]:
        sx = butter(4, cutoff, fs=fs, output='sos')
        ax = sosfiltfilt(sx, acc, axis=0) @ R.T
        mx = derivative(derivative(sosfiltfilt(sx, p, axis=0)))
        mask = t >= original_t[100]
        for j, axis in enumerate('XYZ'):
            cutoff_rows.append([cutoff, axis, np.sqrt(np.mean((ax[mask,j]-mx[mask,j])**2)), np.max(np.abs(mx[:,j]))])
    with (args.out/'cutoff_sensitivity.csv').open('w', newline='') as f:
        writer = csv.writer(f); writer.writerow(['cutoff_hz','axis','evaluation_acceleration_rmse_m_s2','mocap_peak_acceleration_m_s2']); writer.writerows(cutoff_rows)
    fig, axes = plt.subplots(1, 2, figsize=(11,4), constrained_layout=True)
    for axis in 'XYZ':
        rr = [r for r in cutoff_rows if r[1] == axis]
        axes[0].plot([r[0] for r in rr], [r[2] for r in rr], 'o-', label=axis)
        axes[1].plot([r[0] for r in rr], [r[3] for r in rr], 'o-', label=axis)
    axes[0].set(ylabel='Acceleration RMSE (m/s²)', xlabel='Cutoff (Hz)', title='Agreement depends on bandwidth')
    axes[1].set(ylabel='Mocap peak |acceleration| (m/s²)', xlabel='Cutoff (Hz)', title='Lower cutoff also removes signal peaks')
    for ax in axes: ax.legend()
    fig.savefig(args.out/'08_cutoff_sensitivity.png', dpi=160); plt.close(fig)
    arrays = np.column_stack([t, pm, vm, am, ai, vi, pi])
    header = 'time_s,'+','.join(f'{name}_{axis}' for name in ['mocap_p','mocap_v','mocap_a','imu_a','imu_v','imu_p'] for axis in 'xyz')
    np.savetxt(args.out/'processed_data.csv', arrays, delimiter=',', header=header, comments='')
    summary = dict(samples=len(t), duration_s=float(t[-1]), resampled_fs_hz=float(fs),
                   cutoff_hz=args.cutoff, yaw_imu_to_mocap_deg=angle, calibration_squared_error_sum=float(np.min(scores)),
                   initial_position_m=pm[0].tolist(), initial_velocity_m_s=vm[0].tolist(),
                   final_position_error_m=(pi[-1]-pm[-1]).tolist(),
                   final_position_error_norm_m=float(np.linalg.norm(pi[-1]-pm[-1])))
    provided_path = args.data/'BC1rotm.csv'
    if provided_path.exists():
        provided = np.loadtxt(provided_path, delimiter=',')
        summary['provided_matrix_angle_deg_not_used'] = float(np.rad2deg(np.arctan2(provided[1,0], provided[0,0]))%360)
    (args.out/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))
    print('Evaluation acceleration metrics (Mocap is reference):')
    for row in rows:
        if row['quantity']=='acceleration' and row['segment']=='evaluation': print(row)


if __name__ == '__main__':
    main()
