# Week6 Discussion 기준 데이터

이 자료는 이전 Week6_Package의 PPT 기준 결과를 대체하는 Discussion 기준 분석입니다.
새 측정값을 만들어낸 것이 아니라 제공된 CSV를 처리한 데이터입니다.

## 기준
- Discussion C4의 조건: IMU -> Mocap global frame, 처음 100 synchronized samples에서 sum ||Rz(theta) a_IMU - a_Mocap||² 최소화.
- Flowchart의 데이터 구조·행별 Synchronization·고정 Yaw 처리 순서를 참고했습니다. Flowchart의 반대 변환 방향과 Correlation 최대화 기준은 적용하지 않았습니다.
- 최종 각도 72.8°, 0.1° grid search. Closed-form 최소점과 0.05° 이내 일치하는지 코드에서 검증합니다.
- BC1rotm.csv의 각도는 참고로만 기록합니다. 계산에 사용하지 않습니다.
- 이전 288° 버전의 그래프/축별 수치와 섞어 쓰지 마세요. 공통 Coordinate frame이 바뀌어 축별 성능도 바뀝니다.

## 파일 사용 순서
1. results/filter_comparison.csv: 필터 담당자용. 시간, Mocap Acceleration 전후, 회전된 IMU Acceleration 전후. x/y/z는 모두 Mocap frame, 단위 m/s².
2. results/01_filter_effect.png와 07_imu_filter_effect.png: 각 센서의 Filtering 전후 그래프.
3. results/08_cutoff_sensitivity.png와 cutoff_sensitivity.csv: 5/10/15/20 Hz 비교. 15 Hz에서 정한 회전각을 고정합니다. 오차 최소라는 이유만으로 최저 Cutoff를 선택하면 안 됩니다. Peak도 함께 줄어듭니다.
4. results/02_acceleration.png, 03_velocity.png, 04_position.png, 06_trajectory_3d.png: 최종 Discussion용 비교.
5. results/metrics.csv: Calibration 시간대와 이후 평가 구간별 RMSE, MAE, R², Pearson correlation. Mocap이 기준입니다.
6. results/processed_data.csv: time_s, mocap_p(x/y/z), mocap_v, mocap_a, imu_a, imu_v, imu_p. Position m, Velocity m/s, Acceleration m/s².
7. results/yaw_objective.csv와 05_yaw_search.png: 각 후보 angle의 Squared error와 최소점.
8. results/estimated_rotation_imu_to_mocap.csv: 최종 Rotation matrix.

## 기본 결과
2,104 samples, 21.2566 s, 등간격 Resampling 약 98.934 Hz.
15 Hz 조건에서 평가 구간 Acceleration 지표:

| Mocap axis | RMSE (m/s²) | R² | Pearson r |
|---|---:|---:|---:|
| X | 0.7264 | -0.0132 | 0.2147 |
| Y | 0.8314 | 0.7781 | 0.8832 |
| Z | 0.8416 | 0.8605 | 0.9412 |

최종 Position difference: [2.0462, -3.7751, -3.8876] m, 크기 5.7924 m.
이는 실제 이동거리가 아니라 두 Position 추정치의 차이입니다.
교수자 예시 수치와 정확히 동일한 재현은 아닙니다. Frame, Calibration 목적함수 및 전처리 차이를 명시합니다.

## 처리 조건과 한계
- 파일의 각 행이 같은 시점을 나타낸다는 Flowchart 가정을 사용합니다. Mocap에 별도 Timestamp가 없어 독립적으로 Synchronization을 검증하지 못했습니다.
- 실제 시간 간격이 조금 달라 전체 기록을 동일 길이의 등간격 시간축으로 Linear interpolation했습니다. 따라서 출력 CSV 행은 원본 행과 시간이 미세하게 다를 수 있습니다.
- Calibration은 원본 처음 100행만 별도로 등간격 변환하고 Filtering합니다. 이후 데이터를 이용해 각도를 조절하지 않습니다.
- 원본 101번째 sample 시간 이상인 출력 시점을 evaluation으로 사용합니다.
- 기본 필터는 4th-order Butterworth, 설계 Cutoff 15 Hz, SOS forward-backward 적용입니다. Zero phase이지만 합성 필터 차수는 8차이고 설계 Cutoff에서 합성 진폭은 약 -6 dB입니다. 단방향 4차 결과와 다릅니다.
- Mocap Position을 Filtering한 뒤 중앙차분 기반으로 두 번 미분합니다. 경계는 2차 정확도의 편측차분을 사용합니다. IMU Acceleration에도 같은 필터를 적용합니다.
- 고정 Rotation과 동일한 축별 선형 Filtering은 순서를 교환할 수 있습니다. 코드에서는 Filtering 후 IMU에 Rotation을 적용합니다.
- 본 처리의 Zero-phase Filtering은 전체 Recording에 적용됩니다. 구간 경계 주변의 영향이 있으므로 완전히 독립적인 test recording 검증은 아닙니다.
- Acceleration은 m/s²이며 gravity-compensated라는 과제 가정을 사용합니다. 중력을 다시 빼지 않습니다.
- IMU의 초기 Position과 Velocity는 처리된 Mocap에서 가져왔습니다. 독립적 위치 추정 검증은 아닙니다.
- Trapezoidal integration을 사용합니다. Bias removal, ZUPT, Detrending, 끝점 강제 일치를 하지 않아 Drift가 남습니다.
- LPF가 없앤 고주파 성분을 전부 Noise라고 증명할 수는 없습니다. 실제 움직임도 일부 제거될 수 있습니다. 15 Hz는 제공 예시 설정이며 최적값으로 검증된 것은 아닙니다.
- R²<0은 기준 신호 평균만 쓰는 것보다 Squared error가 크다는 뜻입니다. 음의 Correlation과 다릅니다.

## 실행
압축을 풀고 해당 폴더의 터미널에서 실행합니다.

```bash
python -m pip install -r requirements.txt
python week6_analysis.py
```

다른 Cutoff로 전체 재계산: `python week6_analysis.py --cutoff 10 --out results_10Hz`
이 명령은 10 Hz 전처리에서 각도도 다시 추정하므로, 기본 결과 안의 고정각 Cutoff sensitivity와는 다른 실험입니다.
기본 실행은 같은 이름의 results 파일을 덮어씁니다.

## 필터 및 마지막 Discussion 발표에 사용할 결론
Filtering으로 고주파 변동은 줄일 수 있지만 Cutoff가 낮으면 움직임의 Peak도 줄어듭니다.
Mocap frame의 X축 불일치는 Yaw-only 가정, 부착 위치 차이, 잔여 시간차, 미분 오차 등 추가 원인을 조사해야 합니다.
LPF는 일정한 Bias를 제거하지 않습니다. 작은 Acceleration error도 Integration으로 누적되며, 두 번 적분한 Position은 크게 벌어질 수 있습니다.
이번 Drift의 원인을 모두 일정한 Bias 하나로 단정하지는 않습니다.

## 공식 구현 참고
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.sosfiltfilt.html
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.filtfilt.html
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.butter.html
