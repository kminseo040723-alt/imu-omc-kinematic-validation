# Filtering과 최종 Discussion 발표 준비

## 슬라이드 1 약 45초
제목: Effect of Low-pass Filtering
그림: 08_cases_zoom.png 또는 10_cutoff_tradeoff.png. 두 그림을 넣을 경우 작은 글씨가 읽히도록 한 장을 크게 사용하고 다른 결과는 한 문장으로 설명합니다.
핵심 문구:
- Four cases: none / pre / post / both
- Pre and post nearly coincide away from boundaries
- Lower cutoff reduces high-frequency content and signal peaks

발표 원고:
Position을 두 번 미분하면 고주파 Noise가 증폭되므로 Low-pass filtering을 적용했습니다. Mocap에 필터를 적용하지 않은 경우, 미분 전, 미분 후, 전후 모두 적용한 네 경우를 비교했고, IMU의 Filtering 조건과 회전각은 고정했습니다. 이번 데이터에서는 미분 전후 결과가 내부 구간에서 거의 같았습니다. 같은 선형 Filter와 Differentiation은 순서를 바꿔도 비슷한 결과를 내기 때문입니다. 두 번 Filtering하거나 Cutoff를 낮추면 더 매끄러워지지만 실제 움직임의 Peak도 줄어들 수 있습니다.

## 슬라이드 2 약 45초
제목: Remaining Errors and Integration Drift
그림: 04_position.png. Acceleration 결과는 X/Z 상대적으로 양호, Y 낮음으로 짧게 표시합니다.
핵심 문구:
- Baseline: pre-filtering, 15 Hz, IMU global frame
- Small acceleration errors accumulate during integration
- Agreement does not prove absolute accuracy

발표 원고:
최종 비교에는 제공된 예시 설정인 15 Hz를 사용했습니다. Acceleration은 X와 Z에 비해 Y축의 일치도가 낮았고, 두 번 적분한 Position은 마지막에 약 5.79 m 차이가 났습니다. Low-pass filter가 일정한 Bias까지 제거하지는 않기 때문입니다. 일정한 Acceleration bias는 Velocity error를 시간에 비례해, Position error를 시간의 제곱에 비례해 증가시킵니다. Yaw-only 변환 가정과 센서 부착 위치 차이도 오차의 원인 후보입니다. 따라서 필터로 비교 가능성을 높여도 완벽한 정확성이 보장되지는 않습니다.

말하는 속도에 따라 시간이 달라지므로 1회 실제로 읽어 시간을 확인하세요. 초과하면 첫 슬라이드의 pre/post 순서 교환 설명을 한 문장으로 줄이세요.

## 예상 질문
Q. 왜 LPF인가요?
A. 보존하려는 움직임의 Frequency bandwidth보다 높은 성분을 줄이기 위해서입니다. 실제 움직임과 Noise의 Frequency가 겹치면 완벽히 분리할 수 없습니다.

Q. 왜 15 Hz인가요?
A. 제공 자료의 예시 설정입니다. 5/10/15/20 Hz의 RMSE와 Peak 변화를 함께 확인했으며, 가장 작은 RMSE만으로 최적값을 정하지 않았습니다. 필요하면 움직임 Bandwidth의 사전 지식과 Spectrum을 추가 근거로 사용해야 합니다.

Q. Cutoff가 너무 높거나 낮으면요?
A. 높으면 고주파 Noise가 남고 낮으면 실제 움직임의 빠른 변화와 Peak가 줄어듭니다.

Q. 왜 미분 전 Filtering을 기본으로 선택했나요?
A. Position부터 정리하여 Velocity와 Acceleration을 일관되게 계산할 수 있기 때문입니다. 이번 선형 처리에서는 미분 후 방식보다 Acceleration 정확도가 반드시 높다는 뜻은 아닙니다.

Q. both가 RMSE가 작으면 제일 좋은 것 아닌가요?
A. 양쪽 Signal을 매끄럽게 만들어 차이가 작아질 수 있지만 실제 움직임 성분을 잃을 수도 있습니다. 독립적인 ground truth 없이 정확도가 제일 높다고 말할 수 없습니다.

Q. 왜 R²가 음수인가요?
A. 기준 Mocap Signal의 평균값만 사용하는 것보다 Squared error가 크다는 뜻입니다. 반대 방향의 움직임이라는 뜻은 아닙니다.

Q. Y만 안 맞는 원인은요?
A. Frame calibration, Yaw-only 가정, Sensor placement, Timing mismatch, 미분 오차를 확인해야 합니다. 이 데이터만으로 하나의 원인을 확정하지 않았습니다.

Q. 두 센서가 일치하면 정확한가요?
A. 서로의 일치도를 보여줄 뿐입니다. 두 Sensor가 공통 오차를 가질 수도 있고, Mocap에도 Noise가 있습니다.

Q. 5.79 m를 실제로 움직였나요?
A. 아닙니다. 최종 시점의 IMU Position과 Mocap Position 차이의 크기입니다.

Q. Drift가 전부 일정한 Bias 때문인가요?
A. 아닙니다. 일정한 Bias는 누적 원리를 보여주는 예입니다. 실제로는 시간에 따라 변하는 Acceleration error와 초기조건 오차도 영향을 줍니다.
