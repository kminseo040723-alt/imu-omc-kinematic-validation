# Week6 Filtering 발표 자료

## 가장 먼저 볼 파일
`Filtering_Report.html`을 브라우저에서 여세요. 인터넷 없이 그래프와 설명을 볼 수 있습니다.
발표에는 results/08_cases_zoom.png, 10_cutoff_tradeoff.png, 04_position.png 중 2~3개를 고르면 됩니다.
`Presentation_90sec.md`에 슬라이드 구성, 발표 원고, 예상 질문 답변이 있습니다.

## 이번 기준
수정된 최적 Yaw는 287.2°입니다. Correlation 최대화 방식은 폐기하고 Squared error 최소화로 전체 결과를 재계산했습니다.
PPT 우선이며 공통 Frame은 IMU global frame입니다. IMU는 이미 global-frame Acceleration이고, Mocap Position을 IMU frame으로 회전합니다.
처음 100 samples에서 sum ||Rz(theta) a_mocap - a_IMU||²를 최소화합니다. 0.1° 간격으로 탐색하고 Closed-form 최소점과 비교 검증합니다. Correlation은 평가 지표로만 사용하며 각도 선택에는 사용하지 않습니다.
모든 Filtering 비교에서 이 각도를 고정합니다. Filter마다 각도를 다시 추정하면 효과가 섞이기 때문입니다.
이전 Discussion 기준 72.8° 결과와 섞지 마세요. Discussion은 질문 5·6의 분석 범위로 참고하며, Frame은 PPT를 따르고 Calibration은 사용자 지정 Squared error 최소화 기준을 따릅니다.

## Filtering 경우의 수
Mocap은 4가지입니다. D는 Differentiation, F는 Low-pass filtering을 뜻합니다.

| Case | Acceleration 계산 | LPF stage 수 |
|---|---|---:|
| none | D(D(p)) | 0 |
| pre | D(D(F(p))) | 1 |
| post | F(D(D(p))) | 1 |
| both | F(D(D(F(p)))) | 2 |

여기에 IMU raw / IMU LPF 적용의 2가지를 조합하면 8가지입니다.
`eight_combinations_15Hz.csv`는 8가지 × 3축의 평가 지표입니다.
‘미분 후’는 Acceleration을 얻은 후를 뜻합니다. Velocity 단계 Filtering, 다른 Filter 종류·차수·Cutoff까지 가능한 모든 알고리즘을 열거한 것은 아닙니다.

주 비교 그래프는 IMU를 15 Hz Filtering으로 고정하고 Mocap의 4가지 위치만 바꿉니다.
별도 Cutoff 실험은 5/10/15/20 Hz에서 IMU도 같은 Cutoff로 Filtering합니다. Yaw는 고정합니다.

## 데이터 목록
- all_cases_15Hz.csv: time_s, IMU raw/filtered, Mocap none/pre/post/both의 X·Y·Z. 모두 Acceleration m/s², IMU global frame.
- eight_combinations_15Hz.csv: IMU raw/filtered까지 포함한 8가지 조합의 RMSE/R²/Pearson r.
- filter_case_metrics.csv: 4가지 위치 × 4 Cutoff × 3축 × 2평가 구간. RMSE, R², r, Peak, 15 Hz 초과 Power fraction.
- case_data/: 각 Cutoff·Mocap 처리 방식의 Acceleration과 동일 Cutoff IMU Acceleration.
- processed_data.csv: 기준 pre 15 Hz의 두 센서 Position/Velocity/Acceleration. p 단위 m, v 단위 m/s, a 단위 m/s².
- metrics.csv: 기준 pre 15 Hz의 Calibration 시간대/평가 구간별 p/v/a 지표.
- case_summary.json: pre-post의 내부 구간 및 전체 구간 최대 차이.

## 주의해서 해석할 결과
15 Hz에서 pre와 post의 내부 구간 차이는 사실상 수치 오차 수준이며 경계 처리 차이가 남습니다. 정확한 값은 case_summary.json을 확인하세요.
같은 선형 Filter와 차분 연산은 이상적 조건에서 순서를 교환할 수 있습니다. 따라서 pre가 post보다 반드시 우수하다고 결론 내리지 않습니다.
both는 더 강한 Filtering입니다. RMSE 감소만으로 실제 움직임 복원이 더 정확해졌다고 판단하지 않습니다.
R²의 기준은 Mocap입니다. Mocap도 Case마다 바뀌므로 R²만으로 Case의 정확도 순위를 정하면 안 됩니다.
High-frequency power에는 실제 움직임도 포함될 수 있습니다. Noise의 실제 정답을 안다는 뜻이 아닙니다.

## 공통 계산 조건과 한계
2,104 samples, 약 21.2566초. 입력 단위 m, s, m/s²를 사용합니다.
Flowchart에 따라 행별 Synchronization을 가정합니다. 별도 Mocap Timestamp가 없어 독립적인 시간차 검증을 하지 않습니다.
약간 불균일한 Timestamp를 등간격으로 Resampling했습니다. 출력 행은 원본 Timestamp와 조금 다를 수 있습니다.
첫 100개 원본 Sample만 별도로 처리해 Calibration합니다. 이후 결과를 보고 Yaw를 다시 조절하지 않습니다.
4th-order Butterworth를 SOS forward-backward 방식으로 적용합니다. 한 LPF stage가 이미 양방향입니다. 합성 차수는 8차이며 설계 Cutoff에서 약 -6 dB입니다. both는 LPF stage 두 개로 약 -12 dB입니다.
평가 구간은 원본 101번째 sample 시간 이상입니다. interior는 여기서 시작/끝 1초 경계도 제외합니다. 전체 Recording의 Offline Filtering을 쓰므로 독립 Recording 검증은 아닙니다.
미분은 np.gradient를 두 번 적용합니다. 내부는 중앙차분, 끝점은 2차 정확도의 편측차분입니다.
Integration은 Trapezoidal rule을 사용하며 IMU를 gravity-compensated linear acceleration으로 가정합니다. 중력을 다시 빼지 않습니다.
기준 pre15의 초기 Position·Velocity를 Mocap에서 가져왔으며 Bias removal, ZUPT, Detrending 등을 하지 않습니다. 최종 Position 차이는 약 5.79 m입니다.
15 Hz는 교수자 예시 설정입니다. 움직임 ground truth가 없어 최적 Cutoff로 입증하지 않았습니다.

## 재실행
압축을 푼 폴더의 가상환경 터미널에서 실행하세요.

```bash
python -m pip install -r requirements.txt
python week6_analysis.py
```

이 비교 패키지는 고정된 설정으로 전체 경우를 한 번에 계산합니다. Command-line 옵션은 받지 않습니다.
results 파일과 HTML은 다시 생성되어 같은 이름의 파일을 덮어씁니다.

## 원문 근거
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.filtfilt.html
- https://www.mathworks.com/help/signal/ug/take-derivatives-of-a-signal.html
