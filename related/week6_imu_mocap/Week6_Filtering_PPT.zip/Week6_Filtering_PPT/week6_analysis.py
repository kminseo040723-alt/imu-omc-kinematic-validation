"""Week 6: PPT convention, Mocap -> IMU global frame.
Run: python week6_analysis.py
Dependencies: numpy scipy matplotlib
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
from scipy.signal import butter, sosfiltfilt
from scipy.integrate import cumulative_trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def rotation(deg):
    c, s = np.cos(np.deg2rad(deg)), np.sin(np.deg2rad(deg))
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.]])


def correlation(x, y):
    x, y = x-x.mean(), y-y.mean()
    denominator = np.linalg.norm(x)*np.linalg.norm(y)
    return float(x@y/denominator) if denominator > 1e-12 else float('nan')


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=root/'data')
    parser.add_argument('--out', type=Path, default=root/'results')
    parser.add_argument('--cutoff', type=float, default=15.)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    # 1번 담당: 파일 확인. Header가 없는 CSV이므로 첫 행도 데이터입니다.
    imu = np.loadtxt(args.data/'BC1imu_acc.csv', delimiter=',')
    pos = np.loadtxt(args.data/'BC1mc_pos.csv', delimiter=',')
    if imu.ndim != 2 or imu.shape[1] != 4 or pos.shape != (len(imu), 3):
        raise ValueError('Expected IMU N x 4, Mocap N x 3.')
    if not (np.isfinite(imu).all() and np.isfinite(pos).all()):
        raise ValueError('Non-finite input values.')
    original_t = imu[:, 0]-imu[0, 0]
    if not np.all(np.diff(original_t) > 0) or len(imu) <= 100:
        raise ValueError('Need increasing timestamps and more than 100 samples.')
    # PPT가 제공한 row synchronization을 가정합니다. 새 time lag를 추정하지 않습니다.
    t = np.linspace(0, original_t[-1], len(imu))
    dt = t[1]-t[0]
    fs = 1/dt
    if not 0 < args.cutoff < fs/2:
        raise ValueError('Cutoff must be between 0 and Nyquist frequency.')
    resample = lambda x: np.column_stack([np.interp(t, original_t, x[:, j]) for j in range(3)])
    acc = resample(imu[:, 1:])
    p = resample(pos)
    sos = butter(4, args.cutoff, fs=fs, output='sos')
    lowpass = lambda x: sosfiltfilt(sos, x, axis=0)
    derivative = lambda x: np.gradient(x, dt, axis=0, edge_order=2)

    # 2번 담당: Position prefilter -> 두 번 미분. IMU에도 같은 LPF 적용.
    pf = lowpass(p)
    vm = derivative(pf)
    am = derivative(vm)
    raw_am = derivative(derivative(p))
    ai = lowpass(acc)

    # 1번 담당: 원본의 처음 100행만 별도로 처리하여 Calibration에 사용.
    # 전체 신호의 zero-phase filter가 미래 구간을 사용하는 leakage를 피합니다.
    tc = np.linspace(original_t[0], original_t[99], 100)
    dc = tc[1]-tc[0]
    sc = butter(4, args.cutoff, fs=1/dc, output='sos')
    interp_cal = lambda x: np.column_stack([np.interp(tc, original_t[:100], x[:100, j]) for j in range(3)])
    pc = sosfiltfilt(sc, interp_cal(pos), axis=0)
    ac = sosfiltfilt(sc, interp_cal(imu[:, 1:]), axis=0)
    mc = np.gradient(np.gradient(pc, dc, axis=0, edge_order=2), dc, axis=0, edge_order=2)
    angles = np.arange(0, 360, 0.1)
    scores = []
    for angle in angles:
        candidate = mc @ rotation(angle).T  # row vectors: R a -> A R^T
        scores.append(np.sum((candidate-ac)**2))
    scores = np.asarray(scores)
    if not np.isfinite(scores).any():
        raise ValueError('Insufficient horizontal excitation for yaw calibration.')
    angle = float(angles[np.nanargmin(scores)])
    R = rotation(angle)
    exact = np.rad2deg(np.arctan2(np.sum(mc[:,0]*ac[:,1]-mc[:,1]*ac[:,0]),np.sum(mc[:,:2]*ac[:,:2]))) % 360
    assert abs((angle-exact+180)%360-180) <= 0.051
    np.savetxt(args.out/'yaw_objective.csv',np.column_stack([angles,scores]),delimiter=',',header='yaw_deg,squared_error_sum',comments='')
    pm, vm, am, raw_am = [x @ R.T for x in (pf, vm, am, raw_am)]
    # 3번 담당: gravity-compensated linear acceleration이라는 과제 가정.
    # 초기조건을 Mocap에서 가져왔으므로 독립적인 위치 추정 검증은 아닙니다.
    vi = vm[0] + cumulative_trapezoid(ai, t, axis=0, initial=0)
    pi = pm[0] + cumulative_trapezoid(vi, t, axis=0, initial=0)
    # Bias removal, detrending, endpoint fitting, ZUPT를 적용하지 않습니다.

    rows = []
    for quantity, reference, estimate in [('acceleration', am, ai), ('velocity', vm, vi), ('position', pm, pi)]:
        for segment, mask in [('calibration_time', t <= original_t[99]), ('evaluation', t >= original_t[100])]:
            for j, axis in enumerate('XYZ'):
                y, yhat = reference[mask, j], estimate[mask, j]
                error = yhat-y
                sst = np.sum((y-y.mean())**2)
                rows.append(dict(quantity=quantity, segment=segment, axis=axis,
                                 RMSE=float(np.sqrt(np.mean(error**2))),
                                 MAE=float(np.mean(np.abs(error))),
                                 R2=float(1-np.sum(error**2)/sst) if sst > 1e-15 else float('nan'),
                                 correlation=correlation(y, yhat)))
    with (args.out/'metrics.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    plt.rcParams.update({'font.size': 10, 'axes.grid': True, 'grid.alpha': .2})
    def compare(filename, title, y1, y2, labels, unit):
        fig, axes = plt.subplots(3, 1, figsize=(11, 7), sharex=True, constrained_layout=True)
        for j, ax in enumerate(axes):
            ax.plot(t, y1[:, j], label=labels[0], lw=1.1, color='#176bba')
            ax.plot(t, y2[:, j], label=labels[1], lw=1.0, alpha=.85, color='#d65f24')
            ax.axvspan(0, original_t[99], color='grey', alpha=.13)
            ax.set_ylabel(f'{"XYZ"[j]} ({unit})')
        axes[0].legend(loc='upper right', ncol=2)
        axes[-1].set_xlabel('Time (s); shaded interval = calibration')
        fig.suptitle(title+' | IMU global frame')
        fig.savefig(args.out/filename, dpi=160); plt.close(fig)
    compare('01_filter_effect.png', 'Mocap acceleration: effect of position prefiltering', raw_am, am,
            ['Raw position differentiated twice', f'{args.cutoff:g} Hz prefilter then derivatives'], 'm/s²')
    compare('02_acceleration.png', 'Acceleration comparison', am, ai, ['Mocap reference', 'IMU'], 'm/s²')
    compare('03_velocity.png', 'Velocity comparison: one IMU integration', vm, vi, ['Mocap reference', 'IMU integrated'], 'm/s')
    compare('04_position.png', 'Position comparison: two IMU integrations', pm, pi, ['Mocap reference', 'IMU integrated'], 'm')
    fig, ax = plt.subplots(figsize=(10, 4), constrained_layout=True)
    ax.plot(angles, scores); ax.axvline(angle, color='#d65f24', label=f'Selected yaw = {angle} deg')
    ax.set(xlabel='Mocap -> IMU yaw (deg)', ylabel='Sum of squared acceleration errors', title='Calibration: first 100 original samples only')
    ax.legend(); fig.savefig(args.out/'05_yaw_search.png', dpi=160); plt.close(fig)
    # 동일한 축척으로 Trajectory를 비교하여 Drift를 그대로 표시합니다.
    fig = plt.figure(figsize=(8, 7), constrained_layout=True)
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(*pm.T, label='Mocap'); ax.plot(*pi.T, label='IMU integrated')
    both = np.vstack([pm, pi]); center = (both.max(0)+both.min(0))/2
    radius = max(np.ptp(both, axis=0).max()/2, .01)
    ax.set_xlim(center[0]-radius, center[0]+radius); ax.set_ylim(center[1]-radius, center[1]+radius); ax.set_zlim(center[2]-radius, center[2]+radius)
    ax.set_box_aspect((1,1,1)); ax.set(xlabel='X (m)', ylabel='Y (m)', zlabel='Z (m)', title='3D trajectory | IMU global frame'); ax.legend()
    fig.savefig(args.out/'06_trajectory_3d.png', dpi=160); plt.close(fig)
    arrays = np.column_stack([t, pm, vm, am, ai, vi, pi])
    header = 'time_s,'+','.join(f'{name}_{axis}' for name in ['mocap_p','mocap_v','mocap_a','imu_a','imu_v','imu_p'] for axis in 'xyz')
    np.savetxt(args.out/'processed_data.csv', arrays, delimiter=',', header=header, comments='')
    summary = dict(samples=len(t), duration_s=float(t[-1]), resampled_fs_hz=float(fs),
                   cutoff_hz=args.cutoff, yaw_mocap_to_imu_deg=angle, calibration_squared_error_sum=float(np.min(scores)),
                   initial_position_m=pm[0].tolist(), initial_velocity_m_s=vm[0].tolist(),
                   final_position_error_m=(pi[-1]-pm[-1]).tolist(),
                   final_position_error_norm_m=float(np.linalg.norm(pi[-1]-pm[-1])))
    provided_path = args.data/'BC1rotm.csv'
    if provided_path.exists():
        provided = np.loadtxt(provided_path, delimiter=',')
        summary['provided_matrix_angle_deg_not_used'] = float(np.rad2deg(np.arctan2(provided[1,0], provided[0,0]))%360)
    (args.out/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))
    print('Evaluation acceleration metrics (Mocap is reference):')
    for row in rows:
        if row['quantity']=='acceleration' and row['segment']=='evaluation': print(row)



def compare_filter_cases():
    """Four filtering placements; fixed PPT rotation for fair comparison."""
    import base64
    from scipy.signal import welch, sosfreqz
    root = Path(__file__).resolve().parent
    out = root/'results'
    summary = json.loads((out/'summary.json').read_text())
    R = rotation(summary['yaw_mocap_to_imu_deg'])
    raw = np.loadtxt(root/'data/BC1imu_acc.csv', delimiter=',')
    pos = np.loadtxt(root/'data/BC1mc_pos.csv', delimiter=',')
    original_t = raw[:,0]-raw[0,0]
    t = np.linspace(0,original_t[-1],len(raw)); dt = t[1]-t[0]; fs = 1/dt
    interp = lambda x: np.column_stack([np.interp(t,original_t,x[:,j]) for j in range(3)])
    p = interp(pos) @ R.T
    imu = interp(raw[:,1:])
    D = lambda x: np.gradient(x,dt,axis=0,edge_order=2)
    a_raw = D(D(p))
    def filt(x,fc):
        return sosfiltfilt(butter(4,fc,fs=fs,output='sos'),x,axis=0)
    labels = {'none':'No Mocap filter','pre':'Filter position before derivatives',
              'post':'Filter acceleration after derivatives','both':'Filter before and after'}
    colors = {'none':'#888888','pre':'#176bba','post':'#de7b25','both':'#33864a'}
    def variants(fc):
        a_pre = D(D(filt(p,fc)))
        return {'none':a_raw,'pre':a_pre,'post':filt(a_raw,fc),'both':filt(a_pre,fc)}
    main_cases = variants(15)
    imu15 = filt(imu,15)
    masks = {'evaluation':t>=original_t[100],
             'interior':(t>=max(original_t[100],1.)) & (t<=t[-1]-1.)}
    rows=[]; data_dir=out/'case_data';data_dir.mkdir(exist_ok=True)
    for fc in [5,10,15,20]:
        ai = filt(imu,fc)
        for case,am in variants(fc).items():
            header='time_s,'+','.join(f'{name}_{axis}_m_s2' for name in ['mocap_a','imu_a'] for axis in 'xyz')
            np.savetxt(data_dir/f'{case}_{fc}Hz.csv',np.column_stack([t,am,ai]),delimiter=',',header=header,comments='')
            for region,mask in masks.items():
                for j,axis in enumerate('XYZ'):
                    y,z=am[mask,j],ai[mask,j]
                    denom=np.sum((y-y.mean())**2)
                    f,px=welch(y,fs=fs,nperseg=min(512,len(y)))
                    high=float(px[f>15].sum()/px.sum()) if px.sum()>0 else 0.
                    rows.append(dict(cutoff_hz=fc,case=case,region=region,axis=axis,
                        rmse_m_s2=float(np.sqrt(np.mean((z-y)**2))),
                        r2=float(1-np.sum((z-y)**2)/denom),pearson_r=correlation(y,z),
                        mocap_peak_m_s2=float(np.max(np.abs(y))),high_frequency_power_fraction_above_15Hz=high))
    with (out/'filter_case_metrics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    # 주 비교: IMU는 15 Hz로 고정하고 Mocap Filter 위치만 변경합니다.
    combined=np.column_stack([t,imu,imu15]+list(main_cases.values()))
    names=['imu_raw','imu_15Hz']+[f'mocap_{case}' for case in labels]
    np.savetxt(out/'all_cases_15Hz.csv',combined,delimiter=',',header='time_s,'+','.join(f'{n}_{a}_m_s2' for n in names for a in 'xyz'),comments='')
    def plot_cases(filename,zoom):
        fig,axs=plt.subplots(3,1,figsize=(12,8),sharex=True,constrained_layout=True)
        mask=(t>=5)&(t<=7) if zoom else np.ones(len(t),dtype=bool)
        for j,ax in enumerate(axs):
            for case,am in main_cases.items():
                ax.plot(t[mask],am[mask,j],color=colors[case],label=case,lw=1.1,
                        linestyle='--' if case=='post' else '-')
            ax.plot(t[mask],imu15[mask,j],color='black',label='IMU fixed 15 Hz',lw=.9,alpha=.7)
            ax.set_ylabel(f'{"XYZ"[j]} (m/s²)')
        axs[0].legend(ncol=5,fontsize=9,loc='upper right');axs[-1].set_xlabel('Time (s)')
        fig.suptitle('Filtering placement | 15 Hz | fixed Mocap -> IMU yaw')
        fig.savefig(out/filename,dpi=160);plt.close(fig)
    plot_cases('07_cases_full.png',False);plot_cases('08_cases_zoom.png',True)
    # Pre/Post equivalence in the interior, with visible endpoint differences.
    delta=main_cases['pre']-main_cases['post']
    fig,axs=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
    for j,axis in enumerate('XYZ'):
        axs[0].plot(t,delta[:,j],label=axis)
        mask=t<=.5;axs[1].plot(t[mask],delta[mask,j],label=axis)
    axs[0].set(title='Pre minus post: entire record',xlabel='Time (s)',ylabel='Acceleration difference (m/s²)')
    axs[1].set(title='Start boundary detail',xlabel='Time (s)',ylabel='Acceleration difference (m/s²)')
    for ax in axs:ax.legend()
    fig.savefig(out/'09_pre_post_boundary.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
    for j,axis in enumerate('XYZ'):
        rr=[r for r in rows if r['case']=='pre' and r['region']=='evaluation' and r['axis']==axis]
        axs[0].plot([r['cutoff_hz'] for r in rr],[r['rmse_m_s2'] for r in rr],'o-',label=axis)
        axs[1].plot([r['cutoff_hz'] for r in rr],[r['mocap_peak_m_s2'] for r in rr],'o-',label=axis)
    axs[0].set(title='Pre-filter: agreement vs cutoff',xlabel='Cutoff (Hz)',ylabel='RMSE (m/s²)')
    axs[1].set(title='Peak loss vs cutoff',xlabel='Cutoff (Hz)',ylabel='Mocap peak acceleration (m/s²)')
    for ax in axs:ax.legend()
    fig.savefig(out/'10_cutoff_tradeoff.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(3,1,figsize=(11,8),sharex=True,constrained_layout=True)
    for j,ax in enumerate(axs):
        for case,am in main_cases.items():
            f,ps=welch(am[masks['interior'],j],fs=fs,nperseg=512)
            ax.semilogy(f,ps+1e-20,label=case,color=colors[case],linestyle='--' if case=='post' else '-')
        ax.axvline(15,color='black',ls=':');ax.set_ylabel(f'{"XYZ"[j]} PSD')
    axs[0].legend(ncol=4);axs[-1].set_xlabel('Frequency (Hz)');fig.suptitle('Acceleration PSD: high-frequency content is not all proven noise')
    fig.savefig(out/'11_spectrum.png',dpi=160);plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,4),constrained_layout=True)
    f,h=sosfreqz(butter(4,15,fs=fs,output='sos'),worN=2048,fs=fs)
    for power,label in [(1,'One causal pass (reference)'),(2,'One zero-phase LPF stage'),(4,'Two zero-phase LPF stages')]:
        ax.plot(f,20*np.log10(np.maximum(np.abs(h)**power,1e-10)),label=label)
    ax.set(ylim=(-80,3),xlim=(0,40),xlabel='Frequency (Hz)',ylabel='Gain (dB)',title='Why filtering twice changes the effective bandwidth');ax.axvline(15,color='grey',ls=':');ax.legend()
    fig.savefig(out/'12_filter_response.png',dpi=160);plt.close(fig)
    # 4 Mocap placements x 2 IMU settings = 8 combinations at 15 Hz.
    eight=[]
    for case,am in main_cases.items():
        for imu_case,ai in [('raw',imu),('filtered_15Hz',imu15)]:
            for j,axis in enumerate('XYZ'):
                y=am[masks['evaluation'],j];z=ai[masks['evaluation'],j]
                eight.append(dict(mocap_case=case,imu_case=imu_case,axis=axis,
                    rmse_m_s2=float(np.sqrt(np.mean((z-y)**2))),
                    r2=float(1-np.sum((z-y)**2)/np.sum((y-y.mean())**2)),pearson_r=correlation(y,z)))
    with (out/'eight_combinations_15Hz.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(eight[0]));w.writeheader();w.writerows(eight)
    baseline=[r for r in rows if r['cutoff_hz']==15 and r['region']=='evaluation']
    table='<table><tr><th>Case</th><th>Axis</th><th>RMSE (m/s²)</th><th>R²</th><th>r</th></tr>'
    for r in baseline:
        table+=f"<tr><td>{r['case']}</td><td>{r['axis']}</td><td>{r['rmse_m_s2']:.4f}</td><td>{r['r2']:.4f}</td><td>{r['pearson_r']:.4f}</td></tr>"
    table+='</table>'
    details=dict(yaw_deg=summary['yaw_mocap_to_imu_deg'],
        pre_post_interior_max_abs_m_s2=float(np.max(np.abs(delta[masks['interior']]))),
        pre_post_full_max_abs_m_s2=float(np.max(np.abs(delta))))
    (out/'case_summary.json').write_text(json.dumps(details,indent=2))
    # Portable HTML report includes image bytes; no internet needed.
    report='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>Week6 Filtering 비교</title>
    <style>body{font-family:Arial,'Malgun Gothic',sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;line-height:1.7;color:#172b40}h1,h2{color:#135b8c}img{width:100%;height:auto}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{border:1px solid #ccd5de;padding:7px}th{background:#e9f1f8}section{margin:35px 0}p{max-width:950px}@media print{section{break-before:page}img{max-height:700px;object-fit:contain}}</style>
    <h1>Week6 Filtering 위치와 Cutoff 비교</h1>
    <p>PPT 우선: IMU global frame. Mocap을 회전하고, 처음 100 samples의 3축 Acceleration Squared error 합을 최소화합니다. 선택한 회전각을 모든 경우에 고정했습니다. Discussion의 5·6번 질문을 설명하기 위한 자료입니다.</p>
    <h2>비교 조건</h2><p>기본 실험은 IMU Acceleration에 15 Hz LPF를 한 번 적용한 상태로 고정하고, Mocap의 Filter 위치만 바꿉니다. none은 Mocap에 필터가 없다는 뜻입니다. 모든 센서가 raw라는 뜻이 아닙니다.</p>
    <table><tr><th>Case</th><th>Mocap Acceleration 계산</th></tr><tr><td>none</td><td>Position → Differentiation → Differentiation</td></tr><tr><td>pre</td><td>Position → LPF → Differentiation → Differentiation</td></tr><tr><td>post</td><td>Position → Differentiation → Differentiation → LPF</td></tr><tr><td>both</td><td>Position → LPF → Differentiation → Differentiation → LPF</td></tr></table>
    <p>여기서 ‘미분 후’는 두 번 미분한 Acceleration에 적용한다는 뜻입니다. Velocity 단계에 필터를 추가하는 변형까지 전부 열거한 것은 아닙니다.</p>
    <h2>판단</h2><p>이 데이터에서는 pre와 post가 내부 구간에서 거의 같습니다. 같은 선형 Filter와 Differentiation은 이상적인 조건에서 순서를 교환할 수 있기 때문입니다. 유한 길이 데이터의 경계에서는 Padding과 차분 처리 때문에 차이가 납니다. 따라서 ‘미분 후에는 Noise를 제거할 수 없다’고 주장하면 안 됩니다.</p>
    <p>both는 Filtering이 중복되어 고주파를 더 강하게 줄입니다. 이것이 정확도가 더 높다는 증거는 아니며, 움직임의 Peak도 줄일 수 있습니다. 기준 Pipeline으로 pre 15 Hz를 유지하되 최적 Cutoff라고 주장하지 않습니다.</p>
    <h2>15 Hz 결과</h2>'''+table
    captions=[('07_cases_full.png','네 경우 전체 비교','IMU는 동일한 15 Hz 결과로 고정했습니다. 네 경우의 차이는 Mocap Filtering 위치입니다.'),
        ('08_cases_zoom.png','5–7초 확대','pre와 post가 겹치는 것을 확인하세요. both는 다른 크기응답을 가집니다.'),
        ('09_pre_post_boundary.png','경계 효과','필터 위치 차이가 경계에서 더 크게 나타날 수 있습니다.'),
        ('10_cutoff_tradeoff.png','Cutoff 비교','pre Pipeline에서 양쪽 센서의 Cutoff를 함께 변경했습니다. 회전각은 고정했습니다. RMSE가 작아져도 Peak 보존 여부를 함께 판단해야 합니다.'),
        ('11_spectrum.png','Frequency spectrum','15 Hz 이상의 성분이 줄어드는지 확인합니다. Spectrum만으로 실제 움직임과 Noise를 완전히 구별할 수는 없습니다.'),
        ('12_filter_response.png','중복 Filtering의 의미','4차 Butterworth를 forward-backward 적용하면 한 LPF stage의 magnitude가 |H|²입니다. 두 stage면 |H|⁴이며 15 Hz에서 약 -12 dB입니다.'),
        ('02_acceleration.png','최종 Acceleration 비교','기준 pre 15 Hz. IMU global frame의 X·Z에 비해 Y의 일치도가 낮습니다.'),
        ('03_velocity.png','Velocity 비교','초기조건을 맞춰도 Acceleration error가 누적됩니다.'),
        ('04_position.png','Position 비교','최종 두 Position 차이의 크기는 약 5.79 m입니다. 실제 이동거리라는 뜻은 아닙니다.')]
    for filename,title,caption in captions:
        encoded=base64.b64encode((out/filename).read_bytes()).decode()
        report+=f'<section><h2>{title}</h2><p>{caption}</p><img src="data:image/png;base64,{encoded}"></section>'
    report+='''<section><h2>발표 결론</h2><p>Low-pass filtering은 고주파 변동을 줄이지만 작은 Bias까지 제거하지는 않습니다. 일정한 Bias b는 Velocity error bt와 Position error ½bt²를 만듭니다. Yaw-only 가정, 센서 부착 위치, 잔여 Timing mismatch와 미분 오차도 남을 수 있습니다. 두 센서의 일치는 절대적인 정확성을 증명하지 않습니다.</p><p>초기 Position·Velocity는 Mocap에서 가져왔습니다. 완전히 독립적인 Position estimation은 아닙니다. 전체 Recording에 Offline filtering을 사용했으며 경계 효과가 남습니다. 실제 Motion의 ground truth가 없어 최적 Filter를 확정할 수 없습니다.</p><h2>공식 참고</h2><ul><li><a href="https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.filtfilt.html">SciPy forward-backward filtering</a></li><li><a href="https://www.mathworks.com/help/signal/ug/take-derivatives-of-a-signal.html">MathWorks Differentiation과 Noise</a></li></ul></section></html>'''
    (root/'Filtering_Report.html').write_text(report,encoding='utf-8')
    print('CASE SUMMARY:',json.dumps(details))


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        raise SystemExit('This comparison package uses fixed settings. Run: python week6_analysis.py')
    main()
    compare_filter_cases()
