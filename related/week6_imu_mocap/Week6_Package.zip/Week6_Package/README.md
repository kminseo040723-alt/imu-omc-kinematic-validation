# Week 6 IMU and Mocap 비교

## 실행
압축을 푼 뒤 week6_analysis.py가 있는 폴더를 VS Code로 엽니다.
사용 중인 가상환경의 터미널에서 아래를 실행하세요.

```bash
python -m pip install -r requirements.txt
python week6_analysis.py
```

이미 실행한 그래프와 수치는 results 폴더에 있습니다. 코드 실행 없이 PNG를 열어도 됩니다.
Cutoff 변경 예: `python week6_analysis.py --cutoff 10 --out results_10Hz`
기본 실행은 results 내부의 같은 이름 결과 파일을 덮어씁니다.

## 적용 기준과 한계
- 첨부 PPT의 Mocap -> IMU global frame 방향을 사용합니다.
- Discussion 문서는 반대 변환 방향과 Squared error 최소화를 제시합니다. 이 코드는 PPT를 구현한 버전이며 둘을 동일한 지시로 취급하지 않습니다.
- 두 파일은 제공 자료에 따라 행별로 Synchronization되어 있다고 가정합니다. 별도의 time offset은 추정하지 않습니다.
- 시간 간격이 약간 달라 공통 등간격 시간축에 Linear interpolation합니다.
- Position 단위는 m, Acceleration은 m/s²라고 가정하며 Integration 입력은 gravity-compensated linear acceleration입니다. 중력을 추가로 빼지 않습니다.
- 4th-order Butterworth, 15 Hz, forward-backward zero-phase filtering을 사용합니다. 양방향 적용의 최종 크기응답은 단방향 4차와 다릅니다. Offline 분석용입니다.
- Mocap Position을 먼저 Filtering한 뒤 두 번 Differentiation합니다. IMU에도 같은 설정의 LPF를 적용합니다. 필터의 경계 효과와 수치 미분 오차가 남습니다.
- 처음 100개 원본 samples만 별도로 Resampling/Filtering하여 Yaw를 정합니다. 전체 신호의 미래 값이 Calibration filter로 들어가는 것을 막았습니다.
- PPT가 Correlation의 결합 방법을 명시하지 않아 X·Y Pearson r의 산술평균을 최대화했습니다. Z는 Yaw에 의해 바뀌지 않아 각도 선택에서 제외했습니다. Acceleration magnitude만으로는 Yaw를 식별할 수 없습니다.
- 0~359°를 1° 간격으로 검색하고 하나의 고정 Rotation을 전체 구간에 적용합니다.
- 본 처리의 Filtering은 전체 Recording에 적용됩니다. 이후 구간 평가는 독립 Recording 검증이 아니라 같은 Recording의 Calibration 이후 구간 평가입니다.
- 제공 BC1rotm.csv는 방향/산출 조건이 파일 안에 없으므로 각도 참고값으로만 기록하며 fitting에 쓰지 않습니다.
- IMU Integration의 초기 Position과 Velocity는 처리된 Mocap에서 가져옵니다. 따라서 완전히 독립적인 위치 추정 검증은 아닙니다.
- Bias 제거, Detrending, ZUPT, 끝점 강제 일치 같은 추가 보정은 하지 않습니다. Drift를 숨기지 않기 위한 기본 비교입니다.
- RMSE 단위는 Acceleration m/s², Velocity m/s, Position m입니다. R²는 Mocap을 기준 신호로 합니다. R²와 Pearson r²는 일반적으로 같지 않습니다.

## 이번 실행 결과
- 2,104 samples, 21.2566 s, 약 98.934 Hz
- 선택된 Mocap -> IMU Yaw: 288°
- 제공 Rotation matrix의 표준 yaw 해석: 약 291.81° (미사용)
- 평가 구간 Acceleration R²: X 0.806, Y -0.012, Z 0.860
- 평가 구간 Acceleration RMSE: X 0.765, Y 0.790, Z 0.842 m/s²
- 최종 Position 차이의 크기: 약 5.79 m. 실제 이동거리라는 뜻이 아닙니다.
- 교수자 예시의 각도/수치를 정확히 재현한 결과는 아닙니다. Calibration objective, 전처리 및 평가 구간 차이를 명시하세요.

## 그래프 읽기와 발표
1. 01_filter_effect.png: Position prefilter가 미분으로 증폭되는 Noise를 줄이는지 확인합니다.
2. 02_acceleration.png: X·Z는 상대적으로 잘 맞지만 Y에는 큰 차이가 남습니다. Yaw-only 가정, 센서 위치, 잔여 시간차와 미분 오차 등을 후보로 설명하되 원인을 확정하지 마세요.
3. 03_velocity.png: 한 번 Integration했을 때 오차가 누적되는 모습을 봅니다.
4. 04_position.png: 두 번 Integration하면 몇 초 후부터 Position이 크게 벌어집니다.
5. 05_yaw_search.png: 처음 100 samples에서 각도 선택 기준을 보여줍니다.
6. 06_trajectory_3d.png: 동일한 공간 축척으로 두 Trajectory를 비교합니다.

발표의 핵심: Acceleration의 비슷한 모양이 정확한 Position을 보장하지 않습니다.
일정한 Acceleration bias b는 Velocity error bt, Position error 0.5*b*t²를 만듭니다.
이번 Drift가 전부 일정한 Bias 때문이라고 단정할 수는 없습니다. 시간에 따라 달라지는 오차와 초기조건 오차도 영향을 줍니다.

## 역할
1번: 입력 확인, Synchronization 가정, Yaw calibration 및 Frame conversion.
2번: Mocap Differentiation, Filtering 설정과 처리 전후 설명.
3번: IMU Integration, 초기조건, Drift 및 정량 평가.
공동: Pipeline 그림과 최소 두 가지 한계를 포함하여 5분 발표 구성.
